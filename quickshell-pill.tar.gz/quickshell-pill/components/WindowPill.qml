import Quickshell
import Quickshell.Wayland
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import Quickshell.Io
import "../services" as Services

/*
  WindowPill  —  v1.2.2
  ----------
  Tek bir pencere için, o pencerenin üst-orta noktasında duran ince pill.

  ÖNEMLİ TASARIM KARARI:
  Layer-shell PENCERESİNİN kendi boyutu (implicitWidth/Height) SABİTTİR —
  her zaman "açık" haldeki maksimum alan kadar yer kaplar. Böylece:
    - fare, pill'in üstündeyken pill büyüdüğü için konum kaymaz,
    - konum kaymadığı için fare "diğer pencerenin" alanına düşüp
      hover'ın kesilmesi / titreme sorunu yaşanmaz.
  Görsel büyüme/küçülme SADECE içerideki Rectangle'ın height'ı ile,
  ALT KENARI SABİT tutarak (yukarı doğru kalınlaşarak) yapılır — yatayda
  hiç oynama yok, sadece "olduğu yerde kalınlaşma".

  Hem tiling hem floating pencerelerde çalışır; HyprlandWindows servisinden
  gelen x/y/w güncellemelerine göre konumunu her seferinde yeniden hesaplar.
  Renkler services/Colors.qml (matugen colors.json) üzerinden gelir.
*/
PanelWindow {
    id: pill

    // Başlık metni pill genişliğine sığmadığında kayan yazı (marquee)
    // efektinin açık olup olmadığını kontrol eder. false yapılırsa metin
    // taşsa bile kaymaz, sadece elide (...) ile kesilir.
    property bool textScroll: true

    // Minimize edilmiş pencerelerin ekranın hangi kenarına docklanacağını
    // belirler: "top" | "bottom" | "left" | "right". top/bottom seçiliyken
    // dock'lar yatayda (soldan sağa) dizilir; left/right seçiliyken
    // dikeyde (yukarıdan aşağı) dizilir.
    readonly property string docking_side: "right"

    required property var windowData

    readonly property string pillVersion: "1.2.2"

    // ---- ÇOKLU MONİTÖR DÜZELTMESİ (v2) ----
    // ÖNEMLİ: Bir önceki denemede burada, windowData'ya göre PanelWindow.
    // screen'i RUNTIME'da (pencere sürüklendikçe) yeniden atıyorduk.
    // Ancak Quickshell'in resmi örnekleri PanelWindow.screen'i SADECE
    // pencere OLUŞTURULURKEN (Variants ile ekran başına bir instance
    // üretilerek) atıyor; PopupWindow.screen dokümantasyonu "bu, pencereyi
    // taşımak için değiştirilebilir" diye AÇIKÇA belirtirken, PanelWindow
    // için aynı garanti dokümante edilmemiş. Pratikte de bir kez layer-shell
    // surface'i bir Wayland output'una map edildikten sonra, screen
    // property'sini sonradan değiştirmek altta yatan wl_output/zwlr_layer
    // bağlantısını GÜVENİLİR şekilde taşımıyor — surface eski çıktıda
    // "hayalet" kalabiliyor ya da hiç görünmeyebiliyor. Bu da tam olarak
    // bildirilen hatayı açıklıyor: "1. monitörde piller hiç oluşmuyor".
    //
    // Çözüm: screen ataması artık SADECE shell.qml tarafında, PanelWindow
    // OLUŞTURULURKEN yapılıyor (bkz. shell.qml: PillHost). Pencere başka
    // bir monitöre sürüklendiğinde, shell.qml o pill için ESKİ PanelWindow'u
    // yok edip YENİ birini doğru screen ile yeniden oluşturuyor (Loader
    // reset). WindowPill.qml artık kendi "screen"ini hiç yönetmiyor;
    // dışarıdan (host tarafından) required property olarak alıyor.
    required property var targetScreen
    screen: targetScreen

    // ÖNEMLİ (mimari v4): Bu instance artık HER ZAMAN aynı monitöre
    // (targetScreen) atanmış kalıyor — screen bir daha hiç değişmiyor.
    // Pencere gerçekten bu monitördeyken bu property true, başka bir
    // monitördeyken false olur; false olduğunda pill görünmez (visible
    // binding'ine dahil edilir) ama layer-shell surface'i map'li kalır
    // (unmap/remap YOK), bu da monitör geçişlerinde titreme/kaybolma
    // sınıfı hataları yapısal olarak ortadan kaldırır.
    property bool isOnCorrectScreen: true

    // ---- Boyut sabitleri ----
    readonly property int pillWidth: 120          // kapalı genişlik (X ekseninde uzun)
    readonly property int expandedWidth: 300     // açık genişlik
    readonly property int expandedHeight: 30
    readonly property int collapsedHeight: 8   // ince, uzun görünüm

    // Pill sadece TIKLAMA (hover değil, sürükleme de değil) ile açılır.
    // Durum, delegate'in kendisinde değil HyprlandWindows singleton'ında
    // adres bazlı saklanıyor; böylece Variants modeli değiştiğinde delegate
    // yeniden kurulsa bile açık/kapalı durum kaybolmuyor (bkz.
    // HyprlandWindows.expandedState).
    // ÖNEMLİ: Bu, düz bir binding değil; explicit olarak
    // HyprlandWindows.expandedStateChanged sinyaline bağlanıyoruz. Sebep:
    // "expanded: windowData ? isExpandedForced(...) : false" şeklindeki
    // düz binding, isExpandedForced() bir FONKSİYON ÇAĞRISI olduğu için
    // bazı QML sürümlerinde/derleme modlarında (özellikle qmlcachegen ile
    // önceden derlenmiş binding'lerde) fonksiyonun İÇİNDE okunan
    // expandedState[address] property erişimini bağımlılık olarak
    // yakalayamayabiliyor — bu da "state değişti ama binding yeniden
    // değerlendirilmedi" sonucuna, pratikte "ilk tık eskiyi kapatıyor ama
    // yeni pill hemen açılmıyor, ikinci tıkta açılıyor" hatasına yol
    // açabiliyor. Explicit Connections + doğrudan fonksiyon çağrısı bunu
    // derleme moduna bakmaksızın garanti eder.
    property bool expanded: false

    function _syncExpanded() {
        pill.expanded = windowData ? Services.HyprlandWindows.isExpandedForced(windowData.address) : false
    }

    Connections {
        target: Services.HyprlandWindows
        function onExpandedStateChanged() { pill._syncExpanded() }
    }

    onWindowDataChanged: {
        pill._syncExpanded()
        pill._syncIsOnActiveWorkspace()
    }
    Component.onCompleted: {
        pill._syncExpanded()
        pill._syncAnyFullscreen()
        pill._syncIsOnActiveWorkspace()
    }

    // Layer-shell ALANI: her zaman en geniş + en yüksek hale göre sabit.
    // Bu sayede fare, alan içinde her zaman "içeride" kalır; pill'in kendi
    // büyüme/küçülmesi bu alanı değiştirmez, dolayısıyla altındaki pencereye
    // düşüp hover kaybı yaşanmaz.
    readonly property int areaWidth: expandedWidth
    readonly property int areaHeight: expandedHeight

    // Pencere kapandıysa / geçersiz veri gelirse render etme
    // ÖNEMLİ: Sürükleme sırasında (setfloating dispatch edildiğinde,
    // Hyprland pencereyi bir an yeniden map/resize edebiliyor) hyprctl
    // clients çıktısı GEÇİCİ olarak tutarsız (ör. w:0 ya da windowData
    // henüz güncellenmemiş) gelebiliyor. visible bu ANLIK duruma bağlı
    // olduğu için layer-shell surface'i sürükleme sırasında bir anlığına
    // gizlenip tekrar gösteriliyordu (openlayer/closelayer spam'i, pill'in
    // titreyip sürüklemenin "yarıda kesilmesi" buradan kaynaklanıyordu).
    // Sürükleme aktifken visible'ı zorla true tutuyoruz.
    // ÖNEMLİ (layer-shell z-order sınırlaması): wlr-layer-shell protokolünde
    // katmanlar (background/bottom/top/overlay) Hyprland'in normal/floating
    // pencere yığınından TAMAMEN AYRI ve onun HER ZAMAN ÜSTÜNDE sabit bir
    // sistemdir (bkz. hyprwm/Hyprland#7476 — layer öncelik/sırası hâlâ açık
    // bir istek). Yani "bu pencerenin pilli, ÜSTÜNE gelen başka bir floating
    // pencerenin altında kalsın" davranışını layer-shell seviyesinde
    // ayarlamak mümkün değil; pill her zaman render'da en üstte kalır.
    //
    // Bunun yerine davranışı BİZ simüle ediyoruz: FOCUS'a bakılmaksızın,
    // PILL'İN KENDİ İKİ UCU (sol kenarı ve sağ kenarı, pill'in üst kenarı
    // hizasında) GERÇEKTEN başka bir floating pencerenin geometrisinin
    // içine düşüyorsa, bu pill gizlenir. ÖNEMLİ: burada pencerenin
    // (windowData.x/w) uçları DEĞİL, pill'in kendi ekrandaki gerçek
    // konumu kontrol ediliyor — pill her zaman areaWidth genişliğinde ve
    // pencerenin üst-orta noktasına ortalanmış ayrı bir katman olduğu
    // için (bkz. margins.left hesaplaması), pencerenin uçları ile pill'in
    // uçları GENELLİKLE FARKLI noktalardır (pill daha dar/geniş olabilir,
    // pencerenin ortasında durur). Sadece TEK bir nokta yerine pill'in
    // HER İKİ ucu ayrı kontrol edilir; herhangi biri kapalıysa pill
    // gizlenir. Floating pencerenin kendi pilli bu kontrolden muaf (kendi
    // kendini kapatmış sayılmaz). Sürükleme sırasında (dragActive) bu
    // kural devre dışı; sürüklenen pill'in görünürlüğü kesintisiz kalmalı.
    readonly property real _pillLeftX: windowData ? Math.round(windowData.x + (windowData.w / 2) - (areaWidth / 2)) : 0
    readonly property real _pillTopY: windowData ? Math.max(0, windowData.y - 2) : 0

    readonly property bool coveredByFloatingWindow: !dragActive
        && !!windowData
        && (Services.HyprlandWindows.isPointCoveredByFloating(
                windowData.address,
                _pillLeftX,
                _pillTopY
            )
            || Services.HyprlandWindows.isPointCoveredByFloating(
                windowData.address,
                _pillLeftX + areaWidth - 1,
                _pillTopY
            ))
    // Herhangi bir pencere fullscreen olduğunda TÜM pill'ler (fullscreen
    // olan pencerenin kendi pill'i dahil) gizlenir. "Services.HyprlandWindows.windows"
    // burada dolaylı olarak okunuyor (anyWindowFullscreen() içinden) ki bu
    // binding, windows dizisi her değiştiğinde (fullscreen>> event'i
    // sonrası refreshGeometryOnly ile) yeniden değerlendirilsin.
    //
    // ÖNEMLİ (düzeltildi): Bu bayrak DAHA ÖNCE doğrudan PanelWindow.visible
    // içine karıştırılmıştı ("visible: !anyFullscreen && ..."). Bu, fullscreen
    // ANINDA pilleri gizlemede çalışıyordu ama fullscreen'den ÇIKILDIĞINDA
    // pillerin geri GELMEMESİNE yol açıyordu: wlr-layer-shell'de
    // PanelWindow.visible=false, surface'i gerçekten unmap/destroy ediyor;
    // visible tekrar true olduğunda yeni bir surface map edilmesi gerekiyor
    // ve bu, aynı anda değişen diğer "visible" bağımlılıklarıyla (özellikle
    // windowData henüz o anda geçici/eksik geldiyse) YARIŞ DURUMUNA giriyor,
    // pratikte pilin bir daha hiç map edilmemesine (kalıcı gizli kalmasına)
    // neden olabiliyordu. Çözüm: PanelWindow'u fullscreen sırasında da
    // MAP'lİ (visible=true) tutmak, sadece görünürlüğü/etkileşimi
    // "içerik seviyesinde" (kök Item'ın opacity'si + mask'ı boşaltarak)
    // simüle etmek. Böylece surface hiç unmap edilmiyor, fullscreen'den
    // çıkışta anında (hiçbir remap gecikmesi/yarışı olmadan) geri görünür.
    // ÖNEMLİ (düzeltildi — asıl bug burasıydı): "anyFullscreen" daha önce
    // "Services.HyprlandWindows.windows.length >= 0 && ...anyWindowFullscreen()"
    // şeklinde DÜZ bir binding'di. anyWindowFullscreen() bir FONKSİYON
    // ÇAĞRISI olduğu için, tıpkı yukarıdaki "expanded" property'sinde
    // anlatılan sorunla birebir aynı şekilde, bazı QML derleme modlarında
    // (qmlcachegen ile önceden derlenmiş binding'ler) fonksiyonun İÇİNDE
    // okunan "windows" dizisine olan bağımlılık düzgün yakalanamıyordu.
    // Sonuç: fullscreen'e girerken pill'ler doğru gizleniyordu (ilk
    // değerlendirmede windows zaten günceldi) ama fullscreen'den ÇIKINCA
    // binding çoğu zaman YENİDEN DEĞERLENDİRİLMİYORDU — mask/opacity eski
    // (fullscreen=true) değerinde TAKILI KALIYORDU. Pill'ler, ancak
    // "expandedStateChanged" veya "focused" gibi BAŞKA bir binding'i
    // tetikleyen bir olay (örn. başka bir uygulamaya geçip odak değiştirmek)
    // dolaylı olarak bu property'yi de yeniden değerlendirmeye zorlayınca
    // geri geliyordu.
    //
    // Çözüm: expanded'de kullanılan aynı desen — explicit Connections ile
    // HyprlandWindows.windowsChanged sinyaline bağlanıp gerçek bir property'yi
    // elle güncellemek. Bu, derleme moduna bakmaksızın "windows" dizisi her
    // değiştiğinde (fullscreen>> / activewindow>> event'i sonrası
    // refreshGeometryOnly ile) anında yeniden değerlendirilmesini garanti eder.
    property bool anyFullscreen: false

    function _syncAnyFullscreen() {
        const newVal = Services.HyprlandWindows.anyWindowFullscreen()
        pill.anyFullscreen = newVal
    }

    Connections {
        target: Services.HyprlandWindows
        function onWindowsChanged() { pill._syncAnyFullscreen() }
    }

    // ÖNEMLİ (aktif olmayan workspace'teki pencerelerin pili düzeltmesi):
    // Aynı monitörde birden fazla workspace olabilir; o an EKRANDA
    // GÖRÜNMEYEN (aktif olmayan) bir workspace'teki pencere de root.windows
    // listesinde (ve dolayısıyla bu monitöre atanmış pill instance'ında)
    // yer alıyor — sadece "doğru monitörde miyim" (isOnCorrectScreen)
    // kontrolü bunu ELEMİYORDU, çünkü o pencere GERÇEKTEN bu monitördeydi,
    // sadece o anda GÖRÜNMEYEN bir workspace'teydi. Sonuç: kullanıcı
    // workspace 1'deyken workspace 3'teki (aynı monitördeki) pencerelerin
    // pilleri de ekranda duruyordu. Çözüm: pencerenin workspaceId'sinin,
    // atandığı monitörün O ANKİ aktif workspace'i ile eşleşip eşleşmediğini
    // de kontrol etmek. Minimize edilmiş pencereler bu kontrolden muaf
    // (onlar zaten "special:" workspace'e taşınıyor ve kendi dock
    // görünümleriyle HER ZAMAN görünür kalmaları gerekiyor).
    property bool isOnActiveWorkspace: true

    function _syncIsOnActiveWorkspace() {
        if (!windowData || windowData.minimized) {
            pill.isOnActiveWorkspace = true
            return
        }
        const mon = Services.HyprlandWindows.monitorFor(windowData.x + windowData.w / 2, windowData.y)
        pill.isOnActiveWorkspace = !!(mon && mon.activeWorkspace && mon.activeWorkspace.id === windowData.workspaceId)
    }

    Connections {
        target: Services.HyprlandWindows
        function onWindowsChanged() { pill._syncIsOnActiveWorkspace() }
        function onMonitorsChanged() { pill._syncIsOnActiveWorkspace() }
    }

    // ÖNEMLİ (monitörler arası sürüklemenin kesilmesi düzeltmesi): Her
    // pencere için monitör başına AYRI bir PanelWindow instance'ı var
    // (bkz. shell.qml) ve sadece "doğru" (isOnCorrectScreen) olan
    // instance visible/etkileşimli oluyor. Sürükleme SIRASINDA pencere bir
    // monitörden diğerine geçtiği anda "doğru" instance değişiyor —
    // sürüklemeyi BAŞLATMIŞ olan instance'ın kendi Wayland yüzeyi hemen
    // unmap ediliyor, bu da o yüzeye bağlı fare tutuşunu (pointer grab)
    // kesiyor ve kullanıcının sürüklemeyi BIRAKIP YENİDEN TUTMASI
    // gerekiyordu (layer-shell surface'ler tek bir çıktıya/monitöre
    // SABİT bağlı olduğu için tam sorunsuz bir "elden ele" geçiş
    // protokol seviyesinde mümkün değil — bkz. dosyanın üst kısımlarındaki
    // "mimari v4" notları).
    //
    // Kısmi ama etkili çözüm: sürüklemeyi BU instance BAŞLATTIYSA
    // (hoverArea.dragging true), isOnCorrectScreen/isOnActiveWorkspace
    // artık "hayır" dese bile bu instance'ı GÖRÜNÜR/etkileşimli tutuyoruz
    // — yüzey (ve dolayısıyla fare tutuşu) sürükleme BİTENE kadar canlı
    // kalıyor. Pencere gerçekten diğer monitöre geçtiği kısa süre boyunca
    // pill görsel olarak biraz "kopmuş" (kendi ekranının kenarına
    // sıkışmış) görünebilir, ama HAREKET KESİLMİYOR — sürükleme tek bir
    // kesintisiz hareketle tamamlanabiliyor. Sürükleme bitince (dragging
    // false olunca) bu instance normal kurala geri döner; pencere artık
    // GERÇEKTEN başka bir monitördeyse, O monitörün instance'ı devralır.
    visible: (hoverArea.dragging || (isOnCorrectScreen && isOnActiveWorkspace))
        && !coveredByFloatingWindow
        && (dragActive || (windowData !== undefined && windowData !== null && windowData.w > 0))

    // ÖNEMLİ (asıl hitbox düzeltmesi): Layer-shell surface'inin WAYLAND
    // INPUT REGION'I, Qt tarafındaki MouseArea'nın width/height'ına göre
    // OTOMATİK daralmıyor — mask set edilmediği sürece tüm implicit
    // yüzey (areaWidth x areaHeight, yani her zaman expandedWidth x
    // expandedHeight) tıklanabilir kabul ediliyor. Bu yüzden hoverArea'nın
    // width/height'ını collapsed boyuta bağlamak TEK BAŞINA yeterli
    // değildi: compositor seviyesinde fare hâlâ tüm areaWidth alanı
    // içindeyken surface'e event gönderiyordu, Qt de bunu (hatalı ya da
    // eski) geometriyle hit-test edip görsel olarak küçülmüş pill'in
    // dışında bile "içerideymiş" gibi davranabiliyordu. Çözüm: mask'ı
    // (minimized modda parent'ın tamamı, normal modda ise SADECE
    // hoverArea'nın o anki gerçek boyutu) explicit olarak tanımlamak;
    // bu, hem Wayland input region'ını hem Qt hit-test'ini hoverArea'nın
    // güncel width/height'ına gerçekten kilitler — collapsed haldeyken
    // mask da küçük, expanded haldeyken mask da büyük olur.
    //
    // Fullscreen sırasında ise mask'ı TAMAMEN BOŞ bir Region'a (0x0)
    // çeviriyoruz: bu, surface'i unmap etmeden input'u tamamen keser
    // (tüm tıklamalar arkadaki fullscreen pencereye geçer), fullscreen
    // bitince mask otomatik olarak tekrar hoverArea'ya döner.
    //
    // NOT: QML'de bir property binding'i içinde ternary ile iki AYRI
    // inline component literal seçilemez ("a ? Region{...} : Region{...}"
    // parse hatası verir). Bu yüzden iki Region nesnesi burada id ile
    // önceden tanımlanıp mask binding'inde sadece aralarında seçim
    // yapılıyor.
    mask: pill.anyFullscreen ? emptyMaskRegion : hoverMaskRegion

    Region {
        id: emptyMaskRegion
        x: 0
        y: 0
        width: 0
        height: 0
    }

    Region {
        id: hoverMaskRegion
        item: hoverArea
    }

    // NOT: "always on top" davranışı artık layer seviyesinde değil, yukarıdaki
    // "hideBecauseFocusedFloating" ile visible üzerinden simüle ediliyor
    // (bkz. yukarıdaki not). Bu yüzden katmanı tekrar Overlay'e alıyoruz —
    // Overlay, Top'a göre diğer sistem bileşenleriyle (bar, bildirimler vs.)
    // z-sıralaması daha öngörülebilir/stabil.
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.exclusiveZone: -1
    WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
    WlrLayershell.namespace: "window-pill"

    // Minimize edilmiş pencereler İÇİN: ekranın ALT-ORTA kenarına sabit,
    // küçük yuvarlak bir "dock" görünümüne geçiyoruz.
    //
    // ÖNEMLİ (düzeltildi): Daha önce burada left+right+bottom anchor'layıp
    // pencereyi TAM EKRAN GENİŞLİĞİNDE yapıyorduk ("içindeki visualPill
    // zaten ortalanıyor" varsayımıyla). Bu YANLIŞTI: her minimized pencere
    // için ayrı bir layer-shell surface açtığımız için, N tane minimized
    // pencere varsa N tane TAM EKRAN GENİŞLİĞİNDE, üst üste binen şeffaf
    // MouseArea/surface oluşuyordu. Fare nerede olursa olsun sadece EN
    // ÜSTTEKİ (son oluşturulan) pill'in MouseArea'sı input alıyordu — bu
    // yüzden "sadece ortadaki/biri hover oluyor" ve "genişleyince
    // ortalanmıyor" gibi görünüyordu.
    //
    // Doğrusu: her minimized pill kendi DAR (hover genişliği kadar)
    // alanında, ekranın alt-ortasında kendi SLOTUNA göre kaydırılmış bir
    // pencere olmalı. Tam ekran anchor'ı YOK; normal moddaki gibi
    // top+left anchor + hesaplanmış margin kullanılıyor, sadece hedef
    // konum artık pencerenin üstü değil, ekranın alt-orta + slot ofseti.
    anchors {
        top: true
        left: true
    }

    // ---- Konumlandırma ----
    // Normal moddayken: pencerenin üst-orta noktasına yapışık.
    // Minimized moddayken: docking_side'a göre ekranın ilgili kenarına
    // sabit + bu pill'in minimize sırasındaki slotuna göre kaydırma
    // (minimizedSlotOffset). top/bottom dock'ta slot kaydırması yatay,
    // left/right dock'ta dikeydir.
    readonly property real _screenW: screen ? screen.width : 0
    readonly property real _screenH: screen ? screen.height : 0

    // Ekran kenarına olan sabit boşluk (bottom dock'ta önceden hardcode
    // edilen "12" değeriyle aynı, tüm kenarlar için ortak kullanılıyor).
    readonly property int dockEdgeInset: 12

    readonly property bool dockHorizontalAxis: docking_side === "top" || docking_side === "bottom"

    readonly property int minimizedBoxW: (pill.minimizedHovered ? minimizedHoverWidth : minimizedDotSize + minimizedHitPadding * 2)
    readonly property int minimizedBoxH: minimizedDotSize + minimizedHitPadding * 2

    implicitWidth: (windowData && windowData.minimized) ? minimizedBoxW : areaWidth
    implicitHeight: (windowData && windowData.minimized) ? minimizedBoxH : areaHeight

    // ÖNEMLİ (ASIL KÖK NEDEN — çoklu monitör pozisyon bug'ı): windowData.x/y
    // Hyprland'in GLOBAL/layout koordinat sistemindedir (ör. eDP-1 monitörü
    // global layout'ta x=3072'den başlıyorsa, o monitördeki bir pencerenin
    // windowData.x'i ~3078 gibi bir değer olur). Ama PanelWindow.margins,
    // wlr-layer-shell protokolünde HER ZAMAN o PanelWindow'un ATANDIĞI
    // EKRANIN KENDİ YEREL (0,0 başlangıçlı) koordinat sistemine göredir —
    // global koordinat değil. Önceden margins.left/top doğrudan
    // windowData.x/y kullanıyordu; bu, ikinci (ya da global layout'ta
    // orijin olmayan HERHANGİ bir) monitörde pili binlerce piksel EKRAN
    // DIŞINA itiyordu — Loader doğru ekranda PanelWindow'u oluşturuyordu,
    // pill "var" oluyordu ama görünür alanın çok dışında durduğu için asla
    // görünmüyordu. Bu, tam olarak "1. monitörde pill hiç yok ama hata da
    // yok" şikayetini açıklıyor.
    //
    // Çözüm: margin hesaplamasından ÖNCE, pencerenin global x/y'sinden
    // ATANDIĞI monitörün global layout'taki KENDİ x/y ofsetini (mon.x,
    // mon.y — hyprctl monitors -j'den, zaten LOGICAL birimde) çıkarıyoruz.
    // Böylece margins her zaman "bu pencere, kendi ekranının sol-üst
    // köşesinden ne kadar uzakta" şeklinde EKRAN-YEREL bir değer taşıyor.
    function _monitorOffsetFor(x, y) {
        const mon = Services.HyprlandWindows.monitorFor(x, y)
        return mon ? { x: mon.x, y: mon.y } : { x: 0, y: 0 }
    }

    // ÖNEMLİ (monitör sınırında pill kaybolma düzeltmesi): Burada da
    // (shell.qml: isOnCorrectScreen ile AYNI sebepten) pencerenin sol-üst
    // köşesi değil, pill'in GERÇEKTEN ortalandığı nokta (pencerenin yatay
    // ortası) kullanılmalı — aksi halde geniş bir pencere iki monitör
    // arasındaki sınırı geçerken, shell.qml "doğru ekran" olarak BİR
    // monitörü seçip bu instance'ı visible yaparken, buradaki offset
    // BAŞKA bir monitöre göre hesaplanabiliyor; bu tutarsızlık margin'i
    // atanan ekranın sınırları dışına taşırıp pili sınırda kaybediyordu.
    readonly property var _monOffset: windowData
        ? _monitorOffsetFor(windowData.x + windowData.w / 2, windowData.y)
        : { x: 0, y: 0 }

    margins {
        left: (windowData && windowData.minimized)
            ? (dockHorizontalAxis
                ? Math.round(_screenW / 2 - minimizedBoxW / 2 + minimizedSlotOffset)
                : (docking_side === "left" ? dockEdgeInset : Math.round(_screenW - dockEdgeInset - minimizedBoxW)))
            : (windowData ? Math.round((windowData.x - _monOffset.x) + (windowData.w / 2) - (areaWidth / 2)) : 0)
        top: (windowData && windowData.minimized)
            ? (dockHorizontalAxis
                ? (docking_side === "bottom" ? Math.round(_screenH - dockEdgeInset - minimizedBoxH) : dockEdgeInset)
                : Math.round(_screenH / 2 - minimizedBoxH / 2 + minimizedSlotOffset))
            : (windowData ? Math.max(0, Math.round(windowData.y - _monOffset.y) - 2) : 0)
    }


    color: "transparent"

    // Konum sadece pencere gerçekten taşındığında/tiling değiştiğinde
    // yumuşakça kaysın; fare hover'ından bağımsız.
    //
    // ÖNEMLİ: Sürükleme sırasında windowData.x/y her birkaç ms'de bir
    // güncelleniyor (queueDragMove -> refreshGeometryOnly). Bu, margin
    // animasyonunu HER FRAME yeniden tetikliyordu; art arda üst üste binen
    // 140ms'lik NumberAnimation'lar layer-shell surface'inin sürekli
    // resize/commit etmesine, bu da compositor'da pill'in titreyip
    // sürekli "yeniden render oluyormuş" gibi görünmesine ve sürüklemenin
    // fareden geride kalmasına yol açıyordu. Sürükleme sırasında animasyon
    // KAPALI: pill fareyle bire bir, anlık hareket ediyor; sürükleme
    // bitince (dragActive=false) yumuşak geçiş geri açılıyor.
    property bool dragActive: false

    property bool minimizedHovered: false

    // ÖNEMLİ (monitör geçişinde "yanlış yerde belirip kaybolma" düzeltmesi):
    // screen değiştiğinde (targetScreen farklı bir monitöre işaret etmeye
    // başladığında), margins.left/top da AYNI ANDA yeni ekranın ofsetine
    // göre yeni bir değere sıçrıyor. Behavior on margins (140ms yumuşak
    // geçiş animasyonu) bu durumda ESKİ margin değerinden YENİ değere
    // doğru animasyonlu geçiş yapmaya çalışıyordu — ama bu ara kareler
    // ARTIK YENİ ekranda render ediliyor (screen zaten değişmiş), bu da
    // pilin bir anlığına o yeni ekranın YANLIŞ/anlamsız bir noktasında
    // görünüp (eski ekrandaki konumuna karşılık gelen ama yeni ekranda
    // hiçbir anlamı olmayan bir margin değeriyle) sonra doğru yere
    // "zıplamasına" ya da geçici olarak ekran dışına düşüp kaybolmasına
    // yol açıyordu. Çözüm: ekran GERÇEKTEN değiştiği anda animasyonu
    // bir kare boyunca kapatıp konumu ANINDA doğru yere oturtuyoruz;
    // animasyon bir sonraki (aynı ekran içindeki) hareketten itibaren
    // tekrar devrede.
    property bool _screenJustChanged: false
    property var _lastScreen: null

    onScreenChanged: {
        if (screen !== _lastScreen) {
            _lastScreen = screen
            _screenJustChanged = true
            screenChangeSettleTimer.restart()
        }
    }

    Timer {
        id: screenChangeSettleTimer
        interval: 32
        repeat: false
        onTriggered: { pill._screenJustChanged = false }
    }

    Behavior on margins.left {
        enabled: !pill.dragActive && !pill._screenJustChanged
        NumberAnimation { duration: 140; easing.type: Easing.OutCubic }
    }
    Behavior on margins.top {
        enabled: !pill.dragActive && !pill._screenJustChanged
        NumberAnimation { duration: 140; easing.type: Easing.OutCubic }
    }

    // Fare algılama alanı: minimized modda SABİT areaWidth x areaHeight
    // (tüm layer-shell yüzeyini kaplar, hover payı bilinçli olarak geniş).
    // Normal moddaysa artık SADECE görsel pill'in (visualPill) o anki
    // gerçek boyutu kadar (bkz. aşağıdaki MouseArea binding'leri) —
    // collapsed haldeyken hitbox da collapsed boyutunda, expanded
    // olduğunda hitbox da expanded boyutuna büyüyor.
    //
    // Sürükleme: pill açık ya da kapalı halde iken basılı tutulup
    // sürüklenirse, altındaki pencere floating'e çevrilir (henüz değilse)
    // ve fare ile birlikte taşınır. Basit bir tık (sürükleme eşiği
    // aşılmadan bırakılan) pill'in açık/kapalı durumunu toggle eder.
    // Hover ARTIK açmıyor — sadece gerçek (sürüklenmemiş) tık açar/kapatır.
    MouseArea {
        id: hoverArea
        // ÖNEMLİ (küçültme): Normal (minimize olmayan) modda hitbox artık
        // TÜM areaWidth x areaHeight alanını değil, SADECE görsel pill'in
        // (visualPill) o anki gerçek boyutunu kaplıyor. Böylece pill
        // collapsed haldeyken fare, "expanded" halin kapladığı hayali
        // (ama görünmeyen) alana girer girmez değil, sadece görünen ince
        // çubuğun üstündeyken tıklanabilir/etkileşimli oluyor.
        // Minimized dock modunda ise (ayrı bir davranış) fare algılama
        // payı (minimizedHitPadding) bilinçli olarak görsel noktadan daha
        // büyük tutuluyor (bkz. minimizedBoxW/H) — o davranış değişmedi,
        // bu yüzden minimized modda hâlâ parent.fill kullanılıyor.
        anchors.fill: (windowData && windowData.minimized) ? parent : undefined
        anchors.top: (windowData && windowData.minimized) ? undefined : parent.top
        anchors.horizontalCenter: (windowData && windowData.minimized) ? undefined : parent.horizontalCenter
        // ÖNEMLİ (hitbox düzeltmesi): Burada BİLEREK visualPill.width/height
        // (animasyonlu ARA değer) DEĞİL, doğrudan HEDEF boyut kullanılıyor.
        // visualPill'in width/height'ında "Behavior on width/height" (150ms
        // NumberAnimation) var; hitbox bu ara/animasyonlu değere bağlı
        // olsaydı, collapse (expanded->collapsed) sırasında geçiş süresince
        // hitbox hâlâ genişlemiş boyuta yakın kalıp görünen (görsel olarak
        // artık küçülmüş) ince çubuktan gözle görülür şekilde BÜYÜK
        // oluyordu — "collapsed iken hitbox kendisinden büyük" şikayeti
        // buradan kaynaklanıyordu. Hedef boyuta anında kilitlenerek: expand
        // sırasında hitbox hemen büyür (kullanıcı büyüyen pill'i takip
        // edebilir), collapse sırasında ise hitbox hemen küçülür (görsel
        // pill'in küçülme animasyonu bitmesini beklemez).
        width: (windowData && windowData.minimized) ? undefined : (pill.expanded ? pill.expandedWidth : pill.pillWidth)
        height: (windowData && windowData.minimized) ? undefined : (pill.expanded ? pill.expandedHeight : pill.collapsedHeight)
        hoverEnabled: !!(windowData && windowData.minimized)
        acceptedButtons: Qt.LeftButton

        property bool dragging: false
        property bool pressed_: false
        readonly property int dragThreshold: 6

        property real pendingDragX: 0
        property real pendingDragY: 0
        property string pendingDragAddr: ""

        // ÖNEMLİ (yarı-hızda/sallanan sürükleme düzeltmesi — Hyprland/
        // Quickshell güncellemesi sonrası): Bu MouseArea'nın YEREL
        // "mouse.x/y"sinden hesaplanan delta artık sürükleme mesafesi için
        // GÜVENİLİR DEĞİL. Sebep: bu MouseArea, sürüklenen pencereyi görsel
        // olarak takip etmek için HER KAREDE yeniden konumlanan bir
        // PanelWindow'un içinde yaşıyor (bkz. margins.left/top:
        // windowData.x/y'ye bağlı). Yüzeyin kendisi hareket ettikçe yerel
        // koordinat çerçevesi de kayıyor; bu, ölçülüp doğrulanmış bir geri
        // besleme/ölçek sapmasına yol açıyor (tanılamada gerçek imleç
        // hareketinin YARISI kadar ilerlediği ölçüldü). Sabit bir çarpanla
        // "düzeltmek" denendi ama geri beslemeyi güçlendirip pencerenin
        // çılgınca sallanmasına yol açtı (aynı sınıf sorun, aşağıdaki eski
        // "wobble" notunda anlatılan feedback loop'un bir başka türü).
        //
        // Doğru çözüm: sürükleme mesafesini yüzeye göre DEĞİL, Hyprland'in
        // kendi GLOBAL imleç konumuna (hyprctl cursorpos) göre hesaplamak —
        // bu, yüzeyin kendi hareketinden TAMAMEN bağımsızdır, geri besleme
        // oluşamaz. mouse.x/y SADECE "tıklama mı sürükleme mi" eşiğini
        // (aşağıda dragThreshold) tespit etmek için kullanılıyor; bu TEK
        // seferlik, küçük bir karşılaştırma olduğu için feedback'e açık
        // değil.
        property real dragTargetX: 0
        property real dragTargetY: 0
        property real lastCursorX: 0
        property real lastCursorY: 0

        // Dokunmatik sürükleme: Hyprland'in "hyprctl cursorpos" ile
        // raporladığı GLOBAL imleç konumu sadece fareyle güncelleniyor —
        // parmakla sürüklerken bu değer sabit kalıyor (dx/dy hep 0 çıkıyor),
        // bu yüzden dokunmatik sürükleme yukarıdaki cursorPosProc
        // mekanizmasıyla hiç hareket üretmiyordu. Basılma anında event'in
        // mouse.source'una bakarak dokunmatik mi geldiğini tespit edip, o
        // durumda hareketi cursorpos yerine bu MouseArea'nın kendi yerel
        // koordinat farkından (onPositionChanged içindeki dx/dy) besliyoruz.
        property bool isTouchDrag: false

        Timer {
            id: dragThrottleTimer
            interval: 16
            repeat: true
            onTriggered: {
                if (!hoverArea.dragging) {
                    dragThrottleTimer.stop()
                    return
                }
                // Dokunmatik sürüklemede cursorpos hiç güncellenmediği için
                // (bkz. isTouchDrag notu) burada Hyprland'e sormak yerine
                // doğrudan onPositionChanged'in yerel delta'dan hesapladığı
                // en güncel pendingDragX/Y'yi 16ms'de bir dispatch ediyoruz.
                if (hoverArea.isTouchDrag) {
                    if (hoverArea.pendingDragAddr === "") return
                    const luaExpr = "hl.dsp.window.move({x=" + Math.round(hoverArea.pendingDragX) + ", y=" + Math.round(hoverArea.pendingDragY) + ", window=\"address:" + hoverArea.pendingDragAddr + "\"})"
                    Quickshell.execDetached(["hyprctl", "dispatch", luaExpr])
                    return
                }
                // "Meşgul" koruması: önceki cursorpos okuması+dispatch'i
                // henüz bitmediyse bu turu atla (üst üste binen process'ler
                // yaratmamak için) — bir sonraki 16ms'lik turda tekrar
                // denenir.
                if (!cursorPosProc.running) {
                    cursorPosProc.seeding = false
                    cursorPosProc.running = true
                }
            }
        }

        // Sürükleme sırasında Hyprland'in GLOBAL imleç konumunu okur, bir
        // önceki okumaya göre delta'yı hesaplar ve pencereyi o kadar taşır.
        // "seeding" true iken (sürüklemenin ilk karesi) sadece başlangıç
        // referansı (lastCursorX/Y) kaydedilir, henüz hiçbir delta/dispatch
        // uygulanmaz.
        Process {
            id: cursorPosProc
            property bool seeding: false
            command: ["hyprctl", "cursorpos"]
            stdout: StdioCollector {
                id: cursorPosCollector
                onStreamFinished: {
                    const parts = cursorPosCollector.text.trim().split(",")
                    if (parts.length < 2) return
                    const cx = parseFloat(parts[0])
                    const cy = parseFloat(parts[1])
                    if (isNaN(cx) || isNaN(cy)) return

                    if (cursorPosProc.seeding) {
                        hoverArea.lastCursorX = cx
                        hoverArea.lastCursorY = cy
                        return
                    }
                    if (!hoverArea.dragging || !windowData) return

                    const dx = cx - hoverArea.lastCursorX
                    const dy = cy - hoverArea.lastCursorY
                    hoverArea.lastCursorX = cx
                    hoverArea.lastCursorY = cy

                    const newX = Math.round(hoverArea.dragTargetX + dx)
                    const newY = Math.round(hoverArea.dragTargetY + dy)
                    hoverArea.dragTargetX = newX
                    hoverArea.dragTargetY = newY

                    // Pill'in kendi takibi (yerel, IPC'siz) + gerçek
                    // hyprctl dispatch'i (bkz. HyprlandWindows.
                    // updateDraggedWindowLocal notu).
                    Services.HyprlandWindows.updateDraggedWindowLocal(windowData.address, newX, newY)
                    hoverArea.pendingDragX = newX
                    hoverArea.pendingDragY = newY
                    hoverArea.pendingDragAddr = windowData.address

                    const luaExpr = "hl.dsp.window.move({x=" + newX + ", y=" + newY + ", window=\"address:" + windowData.address + "\"})"
                    Quickshell.execDetached(["hyprctl", "dispatch", luaExpr])
                }
            }
        }

        onEntered: if (windowData && windowData.minimized) pill.minimizedHovered = true
        onExited: pill.minimizedHovered = false

        onPressed: mouse => {
            dragging = false
            pressed_ = true
            lastLocalX = mouse.x
            lastLocalY = mouse.y
        }

        property real lastLocalX: 0
        property real lastLocalY: 0

        onPositionChanged: mouse => {
            if (!pressed_) return
            const dx = mouse.x - lastLocalX
            const dy = mouse.y - lastLocalY
            lastLocalX = mouse.x
            lastLocalY = mouse.y

            if (!dragging) {
                if (Math.abs(dx) < dragThreshold && Math.abs(dy) < dragThreshold) return
                dragging = true
                pill.dragActive = true
                Services.HyprlandWindows.dragActive = true
                isTouchDrag = (mouse.source !== undefined && mouse.source !== Qt.MouseEventNotSynthesized)
                // ÖNEMLİ: Burada daha önce "focuswindow" dispatch ediliyordu.
                // Hyprland'de focuswindow bazı durumlarda FARE İMLECİNİ
                // pencerenin merkezine warp ediyor (cursor'ın hedef
                // pencereye "ışınlanması"). Sürükleme sırasında buna hiç
                // gerek yok: setfloating/movewindowpixel zaten adres bazlı
                // ("address:...") çalışıyor, hedef pencereyi odaklamadan
                // da doğrudan etkileyebiliyor. Bu yüzden focuswindow
                // çağrısı tamamen kaldırıldı.
                if (windowData && !windowData.floating) {
                    pill.hlDispatch("hl.dsp.window.float({action=\"toggle\", window=\"" + pill.hlWindowSelector(windowData.address) + "\"})")
                }
                dragTargetX = windowData ? windowData.x : 0
                dragTargetY = windowData ? windowData.y : 0
                if (isTouchDrag) {
                    dragThrottleTimer.start()
                } else {
                    cursorPosProc.seeding = true
                    cursorPosProc.running = false
                    cursorPosProc.running = true
                    dragThrottleTimer.start()
                }
                return
            }

            // Dokunmatik sürüklemede hareketi (cursorpos yerine) buradaki
            // yerel dx/dy'den besliyoruz; dragThrottleTimer bunu 16ms'de
            // bir dispatch ediyor (bkz. isTouchDrag notu yukarıda).
            if (isTouchDrag && windowData) {
                const newX = Math.round(dragTargetX + dx)
                const newY = Math.round(dragTargetY + dy)
                dragTargetX = newX
                dragTargetY = newY
                Services.HyprlandWindows.updateDraggedWindowLocal(windowData.address, newX, newY)
                pendingDragX = newX
                pendingDragY = newY
                pendingDragAddr = windowData.address
            }
        }

        // Sürüklemeyi kesin olarak bitirir: son bilinen konumu (throttle
        // penceresi yüzünden henüz gönderilmemiş olabilecek en güncel
        // konumu) uygular ve tüm sürükleme durumunu sıfırlar. Hem normal
        // bırakma (onReleased) hem de aşağıdaki "monitör değişince pill'in
        // kendi yüzeyi kayboluyor" güvenlik ağı (bkz. pill.onVisibleChanged)
        // TARAFINDAN çağrılır.
        function _finishDrag() {
            dragThrottleTimer.stop()
            if (pendingDragAddr !== "") {
                const luaExpr = "hl.dsp.window.move({x=" + Math.round(pendingDragX) + ", y=" + Math.round(pendingDragY) + ", window=\"address:" + pendingDragAddr + "\"})"
                Quickshell.execDetached(["hyprctl", "dispatch", luaExpr])
            }
            // Ardından: eğer pencere ekranı taşacak kadar büyükse
            // (ör. daha önce maximize edilmişti, şimdi sürüklenip
            // "iptal" edilmiş gibi bırakıldı), taşmayı önlemek için
            // YARIM EKRAN boyutuna küçült.
            pill.clampFloatingSizeIfOversized()
            // ÖNEMLİ: refreshGeometryOnly'yi HEMEN çağırmak yerine kısa
            // bir gecikmeyle (settleTimer) çağırıyoruz. Sebep: yukarıdaki
            // son "movewindowpixel" dispatch'i Hyprland tarafında henüz
            // İŞLENMEMİŞ olabilir; hemen ardından hyprctl clients -j
            // çağrılırsa, ESKİ (sürükleme bitmeden hemen önceki) pozisyon
            // okunup root.windows'a yazılabilir — bu da pilin, sürükleme
            // zaten bittiği halde bir anlığına yanlış/eski konumda
            // (dolayısıyla yanlış monitörde) görünüp sonra doğru yere
            // düzelmesine yol açar. 50ms'lik gecikme, dispatch'in
            // Hyprland tarafında işlenmesi için yeterli pay veriyor.
            dragSettleTimer.restart()
            pill.dragActive = false
            Services.HyprlandWindows.dragActive = false
            dragging = false
            pressed_ = false
            isTouchDrag = false
        }

        onReleased: {
            if (!dragging) {
                if (windowData && windowData.minimized) {
                    // Minimize durumundaki pill'e tıklamak: normal boyutuna
                    // geri döndür (restore).
                    pill.minimizedHovered = false
                    pill.restoreMinimized()
                } else if (windowData) {
                    // Gerçek (sürükleme olmayan) tık: açık/kapalı durumu
                    // kalıcı, adres bazlı store'da toggle et.
                    Services.HyprlandWindows.setExpandedForced(
                        windowData.address,
                        !Services.HyprlandWindows.isExpandedForced(windowData.address)
                    )
                }
                pill.dragActive = false
                Services.HyprlandWindows.dragActive = false
                dragging = false
                pressed_ = false
            } else {
                _finishDrag()
            }
        }

        onCanceled: {
            dragThrottleTimer.stop()
            pill.dragActive = false
            Services.HyprlandWindows.dragActive = false
            dragging = false
            pressed_ = false
            isTouchDrag = false
        }
    }

    // ÖNEMLİ (monitör geçişinde sürükleme kesilmesi/pill kaybolması
    // düzeltmesi): Her pencere için, monitör başına AYRI bir PanelWindow
    // instance'ı var (bkz. shell.qml) ve sürüklenen pencere bir monitörden
    // diğerine geçtiğinde hangi instance'ın "visible" olduğu değişiyor —
    // sürüklemeyi BAŞLATAN instance'ın kendi layer-shell yüzeyi bu anda
    // unmap ediliyor (visible=false). Bu, o yüzeye bağlı Wayland pointer
    // grab'ini yarıda kesiyor; bazı durumlarda bu, Qt'nin normal
    // onReleased/onCanceled callback'lerini hiç TETİKLEMEDEN oluyor —
    // yani hoverArea.dragging/pressed_ ve (daha da önemlisi) GLOBAL
    // Services.HyprlandWindows.dragActive bayrağı SONSUZA KADAR "true"da
    // takılı kalabiliyordu. dragActive takılı kaldığında HyprlandWindows.
    // qml'deki TÜM periyodik geometry/structural yenileme timer'ları
    // ("if (!root.dragActive) ...") kalıcı olarak duraklıyor — bu da SADECE
    // bu pencerenin değil, TÜM pillerin bir daha hiç güncellenmemesine
    // (kalıcı olarak eski/kayıp görünmesine) yol açabiliyordu.
    //
    // Çözüm: pill'in kendi "visible"ı, sürükleme AKTİFKEN false'a düşerse
    // (yani tam da bu senaryoda), bunu "sürükleme bitti" olarak ele alıp
    // normal onReleased'daki İLE AYNI temizlik/son-konum-uygulama
    // mantığını (_finishDrag) çalıştırıyoruz — Wayland'in kendi
    // callback'lerini tetikleyip tetiklemediğine bakılmaksızın durum HER
    // ZAMAN temizleniyor.
    onVisibleChanged: {
        if (!visible && hoverArea.dragging) {
            hoverArea._finishDrag()
        }
    }

    Timer {
        id: dragSettleTimer
        interval: 50
        repeat: false
        onTriggered: Services.HyprlandWindows.refreshGeometryOnly()
    }

    // ---- Görsel pill ----
    // Normal (minimize değilken): alanın ÜST kenarına yapışık, sadece
    // aşağı doğru büyür (Taskbar'ı bloke etmemek için pencerenin üst
    // kenarına yapışıp aşağı doğru açılıyor).
    //
    // Minimize edilmişken: küçük, yuvarlak bir "dock" noktası. Hover'da
    // (fare üstüne gelince) yatayda genişleyip pencere adını gösterir;
    // fare ayrılınca tekrar küçük daireye döner. Tıklamak (hover'dan
    // bağımsız) pencereyi restore eder.
    readonly property int minimizedDotSize: 18   // %25 büyütüldü (önceki: 14)
    readonly property int minimizedHoverWidth: 200   // hover'da SAĞA doğru genişleyen yatay pill genişliği (wclass | title sığsın diye büyütüldü)
    readonly property int minimizedSlotWidth: 220    // her minimized pill'in yatayda kapladığı slot genişliği (hover genişliğinden biraz fazla, komşulara taşmasın diye)
    // Minimized noktanın görünen boyutundan BAĞIMSIZ, her yönde fazladan
    // fare algılama payı. Nokta görsel olarak küçük kalsın ama tıklaması/
    // hover'ı daha kolay olsun diye layer-shell alanı bu kadar büyütülüyor
    // (görsel nokta, büyütülmüş alanın ortasında kalıyor).
    readonly property int minimizedHitPadding: 8

    // Bu pencerenin minimize sırasındaki index'ine göre yatay slot ofseti.
    // Basit soldan-sağa dizilim: index 0 en solda, sonrakiler sağa doğru
    // artan sırada. Yeni bir pencere minimize edildiğinde TÜM grup birden
    // kayıp yeniden ortalanır (toplam sayıya göre -toplamGenişlik/2'den
    // başlanır), böylece noktalar her zaman bir bütün halinde ekranın
    // ortasında durur.
    readonly property int minimizedSlotIndex: (windowData && windowData.minimized) ? Services.HyprlandWindows.minimizedIndexOf(windowData.address) : -1
    readonly property int minimizedTotalCount: (windowData && windowData.minimized) ? Services.HyprlandWindows.minimizedCount() : 0
    readonly property real minimizedSlotOffset: {
        if (minimizedSlotIndex < 0) return 0
        const totalWidth = minimizedTotalCount * minimizedSlotWidth
        const startX = -totalWidth / 2 + minimizedSlotWidth / 2
        return startX + minimizedSlotIndex * minimizedSlotWidth
    }

    Rectangle {
        id: visualPill

        // Fullscreen sırasında görsel olarak da tamamen gizlenir (mask
        // zaten input'u kesiyor, burada ayrıca RENDER'ı da kapatıyoruz ki
        // pill fullscreen pencerenin üstünde görünmesin). Opacity kullanmak
        // (visible=false yerine) tercih edildi: visible=false burada layout/
        // binding zincirini (width/height, anchors) askıya alabiliyor,
        // fullscreen'den çıkışta bazı property'lerin stale kalma riskini
        // taşıyor; opacity ise sadece render'ı etkiler, tüm binding'ler
        // canlı kalır, fullscreen bitince anında (gecikmesiz) geri belirir.
        opacity: pill.anyFullscreen ? 0 : 1
        Behavior on opacity { NumberAnimation { duration: 100 } }

        readonly property bool isMinimized: !!(windowData && windowData.minimized)

        width: isMinimized
            ? (pill.minimizedHovered ? pill.minimizedHoverWidth : pill.minimizedDotSize)
            : (pill.expanded ? pill.expandedWidth : pill.pillWidth)
        height: isMinimized
            ? pill.minimizedDotSize
            : (pill.expanded ? pill.expandedHeight : pill.collapsedHeight)

        anchors.horizontalCenter: parent.horizontalCenter
        anchors.verticalCenter: (isMinimized && !pill.dockHorizontalAxis) ? parent.verticalCenter : undefined
        anchors.top: (!isMinimized) ? parent.top : (isMinimized && pill.dockHorizontalAxis && pill.docking_side === "top" ? parent.top : undefined)
        anchors.bottom: (isMinimized && pill.dockHorizontalAxis && pill.docking_side === "bottom") ? parent.bottom : undefined

        radius: isMinimized ? width / 2 : height / 2

        color: !windowData
            ? Services.Colors.outline
            : (isMinimized
                ? (windowData.focused ? Services.Colors.primary : Services.Colors.outline)
                : (pill.expanded
                    ? (windowData.focused ? Services.Colors.surfaceContainerHigh : Services.Colors.surfaceContainer)
                    : (windowData.focused ? Services.Colors.primary : Services.Colors.outline)))

        border.width: (!isMinimized && pill.expanded) ? 1 : 0
        border.color: Qt.lighter(Services.Colors.outline, 1.3)

        // Sadece boyut animasyonu (yukarı doğru kalınlaşma) + renk geçişi.
        // Konumla (x/y) ilgili HİÇBİR animasyon yok — bu da titremeyi keser.
        Behavior on width {
            NumberAnimation { duration: 150; easing.type: Easing.OutCubic }
        }
        Behavior on height {
            NumberAnimation { duration: 150; easing.type: Easing.OutCubic }
        }
        Behavior on color {
            ColorAnimation { duration: 150 }
        }

        // ---- İçerik (normal mod): başlık + pencere kontrol butonları ----
        RowLayout {
            id: contentRow
            anchors.fill: parent
            anchors.leftMargin: 0
            anchors.rightMargin: 0
            spacing: 10
            visible: !visualPill.isMinimized && pill.expanded
            opacity: visible ? 1 : 0

            Behavior on opacity { NumberAnimation { duration: 120 } }

            // Tiling <-> Floating geçişi (EN SOLDA)
            // Hyprland'in kendi togglefloating dispatcher'ı kullanılıyor;
            // pencere floating ise tiling'e, tiling ise floating'e geçer.
            // Floating'e yeni geçen bir pencere bazen çok büyük/küçük
            // kalabiliyor; bu yüzden floating'e YENİ geçildiyse yarım ekran
            // boyutuna oturtuyoruz (taşmayı önlemek için).
            PillButton {
                symbol: windowData && windowData.floating ? "▤" : "◫"
                bgHover: Services.Colors.surfaceContainerHigh
                fgHover: Services.Colors.textOnSurface
                onClicked: {
                    if (!windowData) return
                    const addr = pill.hlWindowSelector(windowData.address)
                    const wasFloating = windowData.floating === true
                    pill.hlDispatch("hl.dsp.focus({window=\"" + addr + "\"})")
                    pill.hlDispatch("hl.dsp.window.float({action=\"toggle\", window=\"" + addr + "\"})")
                    if (!wasFloating) {
                        // Tiling'den floating'e yeni geçti: yarım ekran
                        // boyutuna, monitörün orta noktasına yerleştir.
                        const mon = Services.HyprlandWindows.monitorFor(windowData.x, windowData.y)
                        const half = pill.halfScreenSizeFor(windowData.x, windowData.y)
                        const originX = mon ? Math.round(mon.x + (mon.width - half.w) / 2) : 0
                        const originY = mon ? Math.round(mon.y + (mon.height - half.h) / 2) : 0
                        pill.hlDispatch("hl.dsp.window.resize({x=" + half.w + ", y=" + half.h + ", window=\"" + addr + "\"})")
                        pill.hlDispatch("hl.dsp.window.move({x=" + originX + ", y=" + originY + ", window=\"" + addr + "\"})")
                    }
                }
            }

            // ---- Başlık: sığmıyorsa 1sn bekleyip kayan yazı (marquee) ----
            Item {
                id: titleClip
                Layout.fillWidth: true
                Layout.alignment: Qt.AlignVCenter
                Layout.preferredHeight: titleText.implicitHeight
                clip: true

                readonly property bool overflowing: titleText.implicitWidth > width
                readonly property real scrollDistance: Math.max(0, titleText.implicitWidth - width)

                Text {
                    id: titleText
                    text: windowData ? (windowData.title || windowData.wclass || "") : ""
                    color: Services.Colors.textOnSurface
                    font.pixelSize: 12

                    x: 0
                    SequentialAnimation {
                        id: marqueeAnim
                        running: pill.textScroll && titleClip.overflowing && pill.expanded
                        loops: Animation.Infinite

                        PauseAnimation { duration: 1000 }
                        NumberAnimation {
                            target: titleText
                            property: "x"
                            from: 0
                            to: -titleClip.scrollDistance
                            duration: Math.max(800, titleClip.scrollDistance * 25)
                            easing.type: Easing.Linear
                        }
                        PauseAnimation { duration: 1000 }
                        NumberAnimation {
                            target: titleText
                            property: "x"
                            from: -titleClip.scrollDistance
                            to: 0
                            duration: Math.max(800, titleClip.scrollDistance * 25)
                            easing.type: Easing.Linear
                        }
                    }

                    // overflowing olmayan/expanded kapanan durumlarda x'i sıfırla
                    onTextChanged: x = 0
                    Connections {
                        target: titleClip
                        function onOverflowingChanged() {
                            if (!titleClip.overflowing) titleText.x = 0
                        }
                    }
                }
            }

            // Minimize / Restore
            // Hyprland'de gerçek bir "minimize" yok; bunu, pencereyi SESSİZCE
            // sabit, görünmeyen bir workspace'e taşıyarak simüle ediyoruz
            // (bkz. pill.minimize / pill.restoreMinimized). Orijinal
            // workspace ID'si HyprlandWindows'daki stash'te saklanıyor, bu
            // yüzden pill hâlâ görünür kalıyor ve tekrar tıklanınca pencere
            // TAM olarak eski workspace'ine geri getiriliyor.
            PillButton {
                symbol: windowData && windowData.minimized ? "▫" : "–"
                bgHover: Services.Colors.tertiary
                fgHover: Services.Colors.textOnTertiary
                onClicked: {
                    if (!windowData) return
                    if (windowData.minimized) {
                        pill.restoreMinimized()
                    } else {
                        pill.minimize()
                    }
                }
            }

            // Maximize / Restore
            // Tiling penceresinde "maksimize", diğer pencerelerin/tiling
            // düzeninin bozulmaması için Hyprland'in kendi
            // "maximize-in-place" fullscreen moduna (fullscreenstate ... 0)
            // bırakılıyor. Floating penceresinde ise ilk tıklama ekranı
            // tam kaplar (100%); pencere zaten büyütülmüşse ikinci tıklama
            // ekranın YARISI boyutuna küçültür (taşmayı önlemek için) —
            // basit bir maximize/restore-to-half toggle.
            PillButton {
                symbol: windowData && windowData.floating ? "▢" : "❐"
                bgHover: Services.Colors.primary
                fgHover: Services.Colors.textOnPrimary
                onClicked: {
                    if (!windowData) return
                    const addr = pill.hlWindowSelector(windowData.address)
                    pill.hlDispatch("hl.dsp.focus({window=\"" + addr + "\"})")

                    if (!windowData.floating) {
                        // Önce tiling pencereyi floating yap, sonra floating
                        // pencere gibi maximize et (kullanılabilir ekran
                        // alanını kaplasın). float dispatch'i senkron
                        // çalıştığından hemen ardından resize/move dispatch
                        // edilebiliyor.
                        pill.hlDispatch("hl.dsp.window.float({action=\"toggle\", window=\"" + addr + "\"})")

                        const usable = pill.usableScreenAreaFor(windowData.x, windowData.y)
                        pill.hlDispatch("hl.dsp.window.resize({x=" + usable.w + ", y=" + usable.h + ", window=\"" + addr + "\"})")
                        pill.hlDispatch("hl.dsp.window.move({x=" + usable.x + ", y=" + usable.y + ", window=\"" + addr + "\"})")
                        return
                    }

                    const mon = Services.HyprlandWindows.monitorFor(windowData.x, windowData.y)
                    const usableForCheck = pill.usableScreenAreaFor(windowData.x, windowData.y)
                    const isNearFullSize = windowData.w >= usableForCheck.w * 0.9 && windowData.h >= usableForCheck.h * 0.9

                    if (isNearFullSize) {
                        // Zaten büyütülmüş: yarım ekran boyutuna küçült.
                        const half = pill.halfScreenSizeFor(windowData.x, windowData.y)
                        const originX = mon ? mon.x : 0
                        const originY = mon ? mon.y : 0
                        pill.hlDispatch("hl.dsp.window.resize({x=" + half.w + ", y=" + half.h + ", window=\"" + addr + "\"})")
                        pill.hlDispatch("hl.dsp.window.move({x=" + originX + ", y=" + originY + ", window=\"" + addr + "\"})")
                    } else {
                        // ÖNEMLİ: "resizeactive exact 100% 100%" + "moveactive
                        // 0 0" pencereyi monitörün TÜM FİZİKSEL alanına
                        // (bar/panel'lerin altına dahi) yayıyordu — çünkü
                        // "%100" Hyprland'de monitörün HAM boyutuna göre
                        // hesaplanıyor, panel'lerin ayırdığı "reserved"
                        // (exclusive zone) alanı hesaba katmıyor. Bu yüzden
                        // pencere waybar/pill gibi panel'lerin ARKASINA
                        // taşıp onları kapatıyordu.
                        //
                        // Doğrusu: hyprctl monitors -j çıktısındaki
                        // "reserved" alanını (panel'lerin kenarlardan
                        // ayırdığı [left, top, right, bottom] piksel
                        // miktarı) düşerek gerçek kullanılabilir alanı
                        // PIXEL cinsinden hesaplayıp hl.dsp.window.resize/
                        // move ile o alana tam oturtuyoruz.
                        const usable = pill.usableScreenAreaFor(windowData.x, windowData.y)
                        pill.hlDispatch("hl.dsp.window.resize({x=" + usable.w + ", y=" + usable.h + ", window=\"" + addr + "\"})")
                        pill.hlDispatch("hl.dsp.window.move({x=" + usable.x + ", y=" + usable.y + ", window=\"" + addr + "\"})")
                    }
                }
            }

            // Close
            PillButton {
                symbol: "✕"
                bgHover: Services.Colors.errorColor
                fgHover: Services.Colors.textOnError
                onClicked: pill.hlDispatch("hl.dsp.window.close({window=\"" + pill.hlWindowSelector(windowData.address) + "\"})")
            }
        }

        // ---- İçerik (minimized mod): sadece hover'da görünen başlık ----
        // Kontrol butonları minimized halde anlamsız (zaten tıklamak
        // restore ediyor), bu yüzden burada sadece pencere adı gösteriliyor.
        Text {
            anchors.fill: parent
            anchors.leftMargin: 10
            anchors.rightMargin: 10
            verticalAlignment: Text.AlignVCenter
            visible: visualPill.isMinimized && pill.minimizedHovered
            opacity: visible ? 1 : 0
            // İstenen format: "wclass | title" (örn. "Dolphin | fish").
            // Hyprland bazı uygulamalar için (özellikle KDE/Qt uygulamaları)
            // "class" alanını ters-DNS şeklinde verir (org.kde.dolphin
            // gibi). Göstermeden önce insan-okunur hale getiriyoruz: son
            // parçayı alıp baş harfini büyütüyoruz (org.kde.dolphin ->
            // Dolphin). Zaten düz bir isimse (ör. "kitty") sadece baş
            // harfi büyütülür.
            function prettyClass(raw) {
                if (!raw) return ""
                const parts = raw.split(".")
                const last = parts[parts.length - 1]
                if (!last) return raw
                return last.charAt(0).toUpperCase() + last.slice(1)
            }
            text: {
                if (!windowData) return ""
                const wclass = prettyClass(windowData.wclass || "")
                const title = windowData.title || ""
                if (wclass && title) return wclass + " | " + title
                return wclass || title
            }
            color: Services.Colors.textOnSurface
            font.pixelSize: 11
            elide: Text.ElideRight

            Behavior on opacity { NumberAnimation { duration: 120 } }
        }
    }

    // Sıralı komut kuyruğu: tek bir cmdProc'u art arda running=false/true
    // yaparak yeniden başlatmak, önceki komut bitmeden iptal edilmesine yol
    // açabiliyordu (özellikle minimize/restore gibi çok adımlı işlemlerde).
    // Bunun yerine komutları bir kuyrukta biriktirip her seferinde bir
    // öncekinin bitmesini bekleyerek sırayla çalıştırıyoruz.
    property var cmdQueue: []
    property bool cmdRunning: false

    // ÖNEMLİ (Hyprland 0.55+ Lua dispatch API kırılması): "hyprctl dispatch
    // <dispatcher> <arg1> <arg2> ..." şeklindeki ESKİ, ayrı argv parçalı
    // sözdizimi artık ÇALIŞMIYOR. Hyprland artık "dispatch" alt komutundan
    // sonra gelen TEK argümanı doğrudan bir Lua ifadesi olarak
    // (`return hl.dispatch(<ifade>)`) değerlendiriyor; "focuswindow
    // address:0x.." gibi eski düz-metin argümanlar geçerli bir Lua ifadesi
    // olmadığı için parse hatası veriyor (sessizce: cmdProc exitCode != 0
    // olup sadece console.log'a düşüyordu, kullanıcı hiçbir hata görmüyordu
    // ama HİÇBİR buton/sürükleme gerçek pencereyi etkilemiyordu). Yeni API,
    // hedef pencereyi "address:0x.." formatında bir string olarak "window"
    // alanına (bkz. hlWindowSelector) alan hl.dsp.* fonksiyonlarını
    // kullanıyor (ör. hl.dsp.window.close({window="address:0x.."})).
    function hlWindowSelector(address) {
        return "address:" + address
    }

    function hlDispatch(luaExpr) {
        dispatch("hyprctl", ["dispatch", luaExpr])
    }

    function dispatch(cmd, args) {
        cmdQueue.push([cmd].concat(args))
        runNextCmd()
    }

    function runNextCmd() {
        if (cmdRunning || cmdQueue.length === 0) return
        cmdRunning = true
        const next = cmdQueue.shift()
        cmdProc.command = next
        cmdProc.running = true
    }

    Process {
        id: cmdProc
        onExited: (exitCode, exitStatus) => {
            if (exitCode !== 0) console.log("[WindowPill] cmd hata verdi, exitCode=" + exitCode + " cmd=" + cmdProc.command.join(" "))
            pill.cmdRunning = false
            pill.runNextCmd()
        }
    }

    // ---- Minimize / Restore ----
    // Hyprland'de resmi bir "minimize" yok. Pencereyi SESSİZCE
    // (movetoworkspacesilent — odak/görünüm değişmez) Hyprland'in kendi
    // "special:" workspace mekanizmasına taşıyarak minimize simüle
    // ediyoruz. "special:" workspace'ler tasarım gereği HİÇBİR monitörde
    // gösterilmez (normal numaralı bir workspace ise bir monitöre bind
    // olabiliyor ve pencere görünür kalabiliyor — canlı testte doğrulandı,
    // sabit rastgele ID'li normal workspace yaklaşımı bu yüzden terk
    // edildi). Restore, pencereyi orijinal workspace ID'sine sessizce
    // geri taşıyarak yapılır.
    //
    // Not: resize/move ile "1x1 yap, ekran dışına taşı" denemesi bazı
    // uygulamalarda (kendi boyutunu yeniden talep eden GTK/Qt pencereleri)
    // işe yaramıyordu; special-workspace tabanlı yöntem tüm pencere
    // tipleri için güvenilir çalışır.
    readonly property string minimizeWorkspaceName: "special:minimized"

    function minimize() {
        if (!windowData) return
        Services.HyprlandWindows.minimizeWindow(windowData.address, {
            workspaceId: windowData.workspaceId,
            origX: windowData.x,
            origY: windowData.y
        })

        const addr = pill.hlWindowSelector(windowData.address)
        // ÖNEMLİ (Hyprland 0.55+ Lua API — eski "movetoworkspacesilent" ile
        // BİREBİR aynı davranış için "follow=false" ŞART): "workspace"
        // hedefi bir "special:" workspace'i olduğunda, hl.dsp.window.move
        // varsayılan olarak (follow belirtilmezse) o özel workspace'i
        // OTOMATİK OLARAK bir monitörde GÖRÜNÜR (overlay) hale getiriyor —
        // pencere odaklı olsun ya da olmasın, taşınan pencere fark etmeksizin
        // her seferinde tetikleniyor (canlı testte doğrulandı: monitors -j
        // çıktısında specialWorkspace anında dolduğu görüldü). Bu da
        // "minimize" tıklandığında pencerenin sessizce KAYBOLMASI yerine bir
        // ekranda GÖRÜNÜR KALMASINA (kullanıcının bildirdiği "minimize
        // çalışmıyor" hatasına) yol açıyordu. "follow=false" bu otomatik
        // gösterimi tamamen kapatıp eski dispatcher'ın sessiz taşıma
        // davranışını geri getiriyor (pencere hâlâ special workspace'e
        // taşınıyor, sadece hiçbir monitörde overlay olarak açılmıyor).
        hlDispatch("hl.dsp.window.move({workspace=\"" + minimizeWorkspaceName + "\", window=\"" + addr + "\", follow=false})")
    }

    function restoreMinimized() {
        if (!windowData) return
        const stash = Services.HyprlandWindows.minimizedStash[windowData.address]
        if (!stash) return

        const addr = pill.hlWindowSelector(windowData.address)
        const targetWs = (stash.workspaceId && stash.workspaceId > 0) ? stash.workspaceId : 1
        hlDispatch("hl.dsp.window.move({workspace=\"" + targetWs + "\", window=\"" + addr + "\", follow=false})")
        hlDispatch("hl.dsp.focus({window=\"" + addr + "\"})")
        Services.HyprlandWindows.restoreWindow(windowData.address)
        Services.HyprlandWindows.refreshGeometryOnly()
    }

    // Bir noktanın üzerinde bulunduğu monitörün YARISI kadar (genişlik ve
    // yükseklik) boyut döndürür. Floating pencereler restore/maximize-toggle
    // sonrasında bu boyuta getirilir ki ekran dışına taşmasınlar.
    function halfScreenSizeFor(x, y) {
        const mon = Services.HyprlandWindows.monitorFor(x, y)
        if (!mon) return { w: 640, h: 480 }
        // ÖNEMLİ (scale düzeltmesi): mon.width/height hyprctl'den FİZİKSEL
        // piksel olarak geliyor, ama movewindowpixel/resizewindowpixel
        // "exact" LOGICAL koordinat/boyut bekliyor (windowData.x/y/w/h ile
        // aynı birim). scale != 1 olan bir monitörde (ör. 1.25) bunu
        // düzeltmeden kullanmak, pencerenin gerçek ekrandan daha büyük
        // boyuta resize edilmesine (ve dolayısıyla sürükleme/maximize
        // sonrasında mouse ile tutarsız, "yanlış oranlı" hareket etmesine)
        // yol açıyordu.
        const scale = (mon.scale && mon.scale > 0) ? mon.scale : 1
        return {
            w: Math.round((mon.width / scale) / 2),
            h: Math.round((mon.height / scale) / 2)
        }
    }

    // Bir noktanın üzerinde bulunduğu monitörün "kullanılabilir" alanını
    // (x, y, w, h) döndürür — yani waybar/panel gibi layer-shell
    // bileşenlerinin exclusiveZone ile kenarlardan AYIRDIĞI alan
    // ("reserved": [left, top, right, bottom], hyprctl monitors -j
    // çıktısından) düşülmüş halidir. Floating bir pencere "maximize"
    // edilirken artık ham "%100 x %100" yerine BU alana tam oturtulur;
    // böylece pencere panellerin arkasına/altına taşıp onları kapatmaz.
    // "reserved" alanı yoksa (eski Hyprland sürümü / veri gelmemiş) ham
    // monitör boyutuna güvenli şekilde geri düşer.
    //
    // Ayrıca her kenardan EK olarak extraPadding kadar (varsayılan 2px)
    // boşluk bırakılır — pencere reserved alanın hemen bitişiğine değil,
    // ondan biraz içeride durur (görsel nefes payı, panellere yapışık
    // görünmesin diye).
    readonly property int maximizeEdgePadding: 2

    function usableScreenAreaFor(x, y) {
        const mon = Services.HyprlandWindows.monitorFor(x, y)
        if (!mon) return { x: 0, y: 0, w: 1920, h: 1080 }

        // ÖNEMLİ (scale düzeltmesi): mon.width/height FİZİKSEL piksel;
        // mon.x/y ve "reserved" alanı ise Hyprland'de LOGICAL birimde.
        // Karışık birimle hesaplarsak (özellikle scale != 1 monitörlerde)
        // "usable" alan gerçek logical ekrandan büyük çıkıyor ve
        // movewindowpixel/resizewindowpixel "exact" ile pencere gerçek
        // ekran sınırlarının dışına taşacak şekilde konumlandırılıyordu.
        const scale = (mon.scale && mon.scale > 0) ? mon.scale : 1
        const logicalW = mon.width / scale
        const logicalH = mon.height / scale

        const r = mon.reserved && mon.reserved.length === 4 ? mon.reserved : [0, 0, 0, 0]
        const [resLeft, resTop, resRight, resBottom] = r
        const p = pill.maximizeEdgePadding

        return {
            x: mon.x + resLeft + p,
            y: mon.y + resTop + p,
            w: Math.max(1, Math.round(logicalW - resLeft - resRight - p * 2)),
            h: Math.max(1, Math.round(logicalH - resTop - resBottom - p * 2))
        }
    }

    // Sürükleme sonrasında pencere, üzerinde bulunduğu monitörün
    // genişlik/yüksekliğine göre "çok büyük" kalmışsa (ör. daha önce
    // maximize edilmiş bir pencere sürüklenip bırakıldıysa), taşmayı
    // önlemek için yarım ekran boyutuna küçültür. Küçükse dokunmaz.
    function clampFloatingSizeIfOversized() {
        if (!windowData || !windowData.floating) return
        const usable = pill.usableScreenAreaFor(windowData.x, windowData.y)
        const isOversized = windowData.w >= usable.w * 0.9 || windowData.h >= usable.h * 0.9
        if (!isOversized) return

        const addr = pill.hlWindowSelector(windowData.address)
        const half = halfScreenSizeFor(windowData.x, windowData.y)
        hlDispatch("hl.dsp.window.resize({x=" + half.w + ", y=" + half.h + ", window=\"" + addr + "\"})")
    }
}
