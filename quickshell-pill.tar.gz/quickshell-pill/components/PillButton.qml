import QtQuick
import QtQuick.Layouts
import "../services" as Services

/*
  PillButton
  ----------
  Pill genişlediğinde beliren küçük daire buton (close / minimize / maximize).
  Renkler matugen paletinden (Colors singleton) besleniyor.
*/
Rectangle {
    id: btn

    property string symbol: ""
    property color bgHover: "#ffffff"
    property color fgHover: "#1c1f26"
    signal clicked()

    // Pill kenarına dayanacak şekilde: RowLayout içine konduğunda dikeyde
    // parent'ın (contentRow'un) TAM yüksekliğini kaplasın, genişlik de
    // buna eşit olsun (kare/daire form korunur).
    //
    // ÖNEMLİ: "implicitWidth: implicitHeight" YANLIŞTI — implicitHeight
    // bu Rectangle için hiç set edilmediği için (Layout.fillHeight sadece
    // height'ı doldurur, implicitHeight'ı değil) implicitWidth de 0/geçersiz
    // kalıyordu; bu yüzden RowLayout tüm butonları sıfır genişlikte,
    // üst üste/bir kenara yığılmış şekilde diziyordu. Doğrusu:
    // Layout.preferredWidth'i GERÇEK height'a bağlamak.
    Layout.fillHeight: true
    Layout.preferredWidth: height
    radius: width / 2
    color: mouseArea.containsMouse ? bgHover : Qt.rgba(1, 1, 1, 0.08)

    Behavior on color { ColorAnimation { duration: 100 } }

    Text {
        anchors.centerIn: parent
        text: btn.symbol
        color: mouseArea.containsMouse ? btn.fgHover : Services.Colors.textOnSurface
        font.pixelSize: Math.round(btn.height * 0.5)
        font.bold: true
    }

    MouseArea {
        id: mouseArea
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: btn.clicked()
    }
}
