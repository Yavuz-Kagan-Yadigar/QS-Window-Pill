pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick

/*
  HyprlandWindows
  ----------------
  hyprctl clients -j ile tüm pencerelerin geometrisini (x, y, w, h),
  floating/tiled durumunu ve adresini çeker.

  Hyprland'in socket2 event stream'ini dinleyerek (openwindow, closewindow,
  movewindow, changefloatingmode, fullscreen, activewindow vs.) her
  değişimde listeyi tazeler. Böylece tiling sonrası pill konumları da
  anında güncellenir.
*/
Item {
    id: root

    // Dışarıya açılan pencere listesi: her eleman
    // { address, title, class, x, y, w, h, floating, mapped, focused }
    property var windows: []

    // Verilen (x, y) noktası, `excludeAddress` DIŞINDAKİ herhangi bir
    // floating pencerenin dikdörtgeni içine düşüyor mu? WindowPill.qml
    // bunu, kendi pilinin konumunun (pencerenin üst-orta noktası) başka
    // bir floating pencere tarafından GERÇEKTEN kapatılıp kapatılmadığını
    // (odak durumundan bağımsız, sadece geometriye bakarak) kontrol etmek
    // için kullanır — bkz. WindowPill.qml: coveredByFloatingWindow.
    function isPointCoveredByFloating(excludeAddress, x, y) {
        for (const w of windows) {
            if (w.address === excludeAddress) continue
            if (!w.floating) continue
            if (w.minimized) continue
            if (x >= w.x && x < w.x + w.w && y >= w.y && y < w.y + w.h) {
                return true
            }
        }
        return false
    }

    // Herhangi bir pencere (odaklı ya da değil) TAM EKRAN (fullscreen)
    // durumdaysa true döner. WindowPill.qml bunu, fullscreen bir pencere
    // varken TÜM pill'leri (o pencerenin kendisi dahil) gizlemek için
    // kullanır — fullscreen'de pencere zaten tüm ekranı kapladığından
    // üstünde duran pill'ler görsel olarak rahatsız edici/gereksiz olur
    // ve bazı oyun/video oynatıcılarda giriş odağını bozabilir.
    // NOT: Bilerek monitör bazlı değil, genel (herhangi bir monitörde)
    // kontrol ediliyor; birden fazla monitör olsa da basit ve öngörülebilir
    // davranış için tüm pill'ler birlikte gizlenir/gösterilir.
    function anyWindowFullscreen() {
        for (const w of windows) {
            if (w.fullscreen && !w.minimized) return true
        }
        return false
    }

    // ÖNEMLİ (socket bağlantı hatası düzeltmesi): Quickshell process'inin
    // ortamındaki HYPRLAND_INSTANCE_SIGNATURE env değişkeni, Quickshell'in
    // NASIL başlatıldığına bağlı olarak boş/eski/yanlış olabiliyor (ör.
    // elle bir terminalden `quickshell -c ...` çalıştırıldığında, terminal
    // shell'in kendi ortamı gerçek Hyprland compositor session'ından farklı
    // bir signature miras almış olabiliyor). Bu durumda socketPath()
    // yanlış bir yola işaret ediyor ve eventSocket hiç bağlanamıyor
    // ("QLocalSocket::ServerNotFoundError") — socket2 event stream'i
    // TAMAMEN sessizce devre dışı kalıyor, sistem sadece 600ms'lik yedek
    // polling'e düşüyor (pil ekle/sil gecikmeli, sürükleme/monitör geçişi
    // sırasında akıcılık kayboluyor).
    //
    // Çözüm: env'den okunan signature'a HER ZAMAN güvenmek yerine,
    // `hyprctl instances -j` ile GERÇEKTEN çalışan Hyprland instance'ının
    // signature'ını sorup, env'deki değer bu listede yoksa (ya da boşsa)
    // ilk (tek) çalışan instance'ın signature'ını kullanıyoruz. Bu değer
    // hazır olana kadar socket'i AÇMIYORUZ (boş sig ile bağlanmayı
    // denemek zaten başarısız oluyordu); resolvedHyprSig doldurulduktan
    // sonra socket bağlantısı (yeniden) kuruluyor.
    property string envHyprSig: Quickshell.env("HYPRLAND_INSTANCE_SIGNATURE") ?? ""
    property string resolvedHyprSig: ""
    readonly property string xdgRuntime: Quickshell.env("XDG_RUNTIME_DIR") ?? "/tmp"

    function socketPath(name) {
        if (!resolvedHyprSig) return ""
        // ÖNEMLİ (asıl kök neden): Hyprland, socket dosyalarını GİZLİ
        // isimlerle oluşturuyor: ".socket.sock" ve ".socket2.sock" (başında
        // nokta var). Burada önceden "socket2.sock" (noktasız) yolu
        // oluşturuluyordu — bu dosya hiçbir zaman var olmadığı için Socket
        // component'i sürekli "QLocalSocket::ServerNotFoundError" veriyordu
        // ve event stream'e HİÇ bağlanılamıyordu (kullanıcının "ls" çıktısı
        // -a olmadan bu dosyaları göstermediği, buna rağmen gerçekte var
        // oldukları doğrulandı). Doğru yol: "." + name + ".sock".
        return xdgRuntime + "/hypr/" + resolvedHyprSig + "/." + name + ".sock"
    }

    Process {
        id: instancesProc
        command: ["hyprctl", "instances", "-j"]
        stdout: StdioCollector {
            id: instancesCollector
            onStreamFinished: {
                try {
                    const list = JSON.parse(instancesCollector.text)
                    if (!Array.isArray(list) || list.length === 0) {
                        return
                    }
                    // env'deki signature listede var mı kontrol et.
                    const envMatch = list.find(inst => inst.instance === root.envHyprSig)
                    const chosen = envMatch ? envMatch.instance : list[0].instance
                    if (chosen && chosen !== root.resolvedHyprSig) {
                        root.resolvedHyprSig = chosen
                    }
                } catch (e) {
                }
            }
        }
    }

    function resolveHyprSig() {
        instancesProc.running = false
        instancesProc.running = true
    }

    // ---- Pencere listesini yenile (hyprctl clients -j) ----
    //
    // ÖNEMLİ: Daha önce burada İKİ AYRI process vardı (clientsProc +
    // geomProc), ikisi de bağımsız olarak "hyprctl clients -j" çalıştırıp
    // root.windows'a yazıyordu. Bu iki process birbirinden habersiz
    // olduğu için YARIŞ DURUMU oluşuyordu: closewindow event'i clientsProc
    // ile tam yeniden inşa (kapanan pencereyi siler) yaparken, tam o
    // sırada 50/200ms Timer'ın tetiklediği geomProc'un (eski, pencere
    // hâlâ kapanmamışken alınmış) cevabı DAHA GEÇ gelirse, o cevap kapanan
    // pencereyi root.windows'a GERİ YAZIYORDU (ya da yeni açılan pencere
    // clientsProc'un cevabı gelene kadar geomProc tarafından hiç
    // eklenmiyordu). Sonuç: kapanan pencerenin pili kalıcı olarak
    // ekranda kalabiliyor, yeni açılan pencereye pil hiç eklenmeyebiliyordu.
    //
    // Çözüm: TEK process, TEK "meşgul" durumu. Hem yapısal (ekle/sil)
    // hem saf geometri güncellemeleri artık aynı clientsProc/parsed
    // veriyi kullanıyor; structural=true ise pencere SAYISI da güncellenir
    // (ekleme/silme), structural=false ise sadece mevcut pencerelerin
    // alanları referans-stabil şekilde güncellenir.
    property bool pendingStructural: false

    Process {
        id: clientsProc
        command: ["hyprctl", "clients", "-j"]
        stdout: StdioCollector {
            id: clientsCollector
            onStreamFinished: {
                try {
                    const raw = JSON.parse(clientsCollector.text)
                    const byAddr = {}
                    const order = []
                    for (const c of raw) {
                        if (!c.mapped) continue
                        byAddr[c.address] = c
                        order.push(c.address)
                    }

                    if (root.pendingStructural) {
                        // Yapısal: pencere SAYISI değişmiş olabilir (aç/kapa).
                        // Var olan pencereler için (adres eşleşiyorsa) eski
                        // referansı koru (gereksiz delegate yeniden kurulmasın),
                        // yeni pencereler için taze obje oluştur, artık var
                        // olmayanları listeden çıkar.
                        const oldByAddr = {}
                        for (const w of root.windows) oldByAddr[w.address] = w

                        const buildEntry = (addr) => {
                            const c = byAddr[addr]
                            const old = oldByAddr[addr]
                            const fresh = {
                                address: c.address,
                                title: c.title,
                                wclass: c["class"],
                                x: c.at[0],
                                y: c.at[1],
                                w: c.size[0],
                                h: c.size[1],
                                floating: c.floating === true,
                                fullscreen: c.fullscreen && c.fullscreen !== 0,
                                workspaceId: c.workspace ? c.workspace.id : -1,
                                focused: old ? old.focused : false,
                                minimized: root.isMinimized(c.address)
                            }
                            if (old
                                && old.x === fresh.x && old.y === fresh.y
                                && old.w === fresh.w && old.h === fresh.h
                                && old.floating === fresh.floating
                                && old.fullscreen === fresh.fullscreen
                                && old.workspaceId === fresh.workspaceId
                                && old.minimized === fresh.minimized
                                && old.title === fresh.title
                                && old.wclass === fresh.wclass) {
                                return old   // hiçbir şey değişmedi: eski referansı koru
                            }
                            return fresh
                        }

                        // ÖNEMLİ: hyprctl'nin döndürdüğü sıra (order) odak
                        // değiştiğinde bile değişebiliyor (Hyprland'in dahili
                        // client yığın sırası). Bu sırayı DOĞRUDAN kullanmak,
                        // pencerelerin kendisi hiç hareket etmediği halde
                        // Variants'taki index-bazlı delegate<->pencere
                        // eşleşmesinin kaymasına yol açıyordu — sonuç olarak
                        // pil'ler gereksiz yere animasyonla birbirinin yerine
                        // "atlıyormuş" gibi görünüyordu (etiketler doğru
                        // pencereye göre güncellense de, konum animasyonu
                        // rahatsız edici bir titreşim/kayma yaratıyordu).
                        // Çözüm: mevcut pencereler için ÖNCEKİ SIRAYI koru,
                        // sadece gerçekten YENİ pencereleri sona ekle,
                        // kapananları listeden düş. hyprctl'nin ham sırası
                        // sadece "hangi adresler hâlâ var" bilgisini almak
                        // için kullanılıyor, dizilim için değil.
                        const stillPresent = {}
                        for (const addr of order) stillPresent[addr] = true
                        const stableOrder = root.windows
                            .filter(w => stillPresent[w.address])
                            .map(w => w.address)
                        const seen = {}
                        for (const addr of stableOrder) seen[addr] = true
                        for (const addr of order) {
                            if (!seen[addr]) {
                                stableOrder.push(addr)
                                seen[addr] = true
                            }
                        }

                        const rebuilt = stableOrder.map(buildEntry)

                        root.windows = rebuilt
                        root.pendingStructural = false
                        activeWinProc.running = true
                    } else {
                        // Sadece geometri/durum güncellemesi: pencere SAYISI
                        // değişmiyor (structural bir olay yok), sadece
                        // GERÇEKTEN değişen alanlara sahip pencerelere yeni
                        // referans veriliyor; değişmeyenler aynı referansta
                        // kalıyor. Hiçbir eleman değişmediyse array'in
                        // kendisi de yeniden atanmıyor (Variants'ın delegate
                        // yeniden kurmasını önlemek için).
                        const mapped = root.windows.map(w => {
                            const c = byAddr[w.address]
                            if (!c) return w
                            const nx = c.at[0], ny = c.at[1]
                            const nw = c.size[0], nh = c.size[1]
                            const nfloating = c.floating === true
                            const nfullscreen = c.fullscreen && c.fullscreen !== 0
                            const nws = c.workspace ? c.workspace.id : -1
                            const nminimized = root.isMinimized(w.address)
                            const ntitle = c.title
                            const nclass = c["class"]

                            if (w.x === nx && w.y === ny && w.w === nw && w.h === nh
                                && w.floating === nfloating && w.fullscreen === nfullscreen
                                && w.workspaceId === nws && w.minimized === nminimized
                                && w.title === ntitle && w.wclass === nclass) {
                                return w
                            }

                            return Object.assign({}, w, {
                                title: ntitle,
                                wclass: nclass,
                                x: nx,
                                y: ny,
                                w: nw,
                                h: nh,
                                floating: nfloating,
                                fullscreen: nfullscreen,
                                workspaceId: nws,
                                minimized: nminimized
                            })
                        })

                        const anyChanged = mapped.length !== root.windows.length
                            || mapped.some((w, i) => w !== root.windows[i])
                        if (anyChanged) {
                            root.windows = mapped
                        }
                    }
                } catch (e) {
                    console.warn("HyprlandWindows: clients parse error", e)
                    root.pendingStructural = false
                }
                root.clientsProcBusy = false
                if (root.clientsProcQueuedStructural) {
                    root.clientsProcQueuedStructural = false
                    root.refresh()
                } else if (root.clientsProcQueuedGeometry) {
                    root.clientsProcQueuedGeometry = false
                    root.refreshGeometryOnly()
                }
            }
        }
    }

    // Tek process, tek "meşgul" durumu: yapısal istek her zaman geometri
    // isteğinden ÖNCELİKLİDİR (kuyruğa iki türden biri varsa yapısal olan
    // çalıştırılır) çünkü ekle/sil doğruluğu, konum tazeliğinden daha
    // önemlidir.
    property bool clientsProcBusy: false
    property bool clientsProcQueuedStructural: false
    property bool clientsProcQueuedGeometry: false

    function refresh() {
        if (clientsProcBusy) {
            clientsProcQueuedStructural = true
            return
        }
        clientsProcBusy = true
        pendingStructural = true
        clientsProc.running = true
        // ÖNEMLİ (maximize/reserved-alan bug'ı): refreshMonitors() eskiden
        // SADECE Component.onCompleted'da, shell ilk açıldığı anda, BİR
        // KEZ çağrılıyordu. root.monitors (dolayısıyla her monitörün
        // "reserved" alanı — panel/bar'ların exclusiveZone ile
        // kenarlardan ayırdığı alan) bir daha hiç güncellenmiyordu. Bar,
        // shell'den sonra başlayıp exclusiveZone'unu shell'in ilk
        // okumasından SONRA set ederse, pill BAYAT/sıfır "reserved"
        // değeriyle çalışıp maximize'ı barı hesaba katmadan tüm ekrana
        // yayıyordu. Artık her yapısal refresh'te (pencere açılma/kapanma/
        // fullscreen event'lerinde, ayrıca 600ms güvenlik timer'ında)
        // monitör verisi de tazeleniyor.
        refreshMonitors()
    }

    function refreshGeometryOnly() {
        if (clientsProcBusy) {
            clientsProcQueuedGeometry = true
            return
        }
        clientsProcBusy = true
        pendingStructural = false
        clientsProc.running = true
    }

    // ---- Kalıcı, adres bazlı UI durumu ----
    // "expandedForced" (pill'in tıklamayla açık tutulup tutulmadığı) artık
    // WindowPill delegate'inin İÇİNDE değil, burada saklanıyor. Sebep:
    // Variants/Repeater modeli her değiştiğinde (root.windows'a yeni bir
    // dizi atandığında) delegate'ler indekse göre yeniden kullanılıyor/
    // yeniden kuruluyor olabilir; delegate içinde tutulan durum bu sırada
    // kaybolup pill'in "kapanıp yeniden açılmış" gibi görünmesine yol
    // açıyordu. Durumu adres bazlı burada saklamak, delegate yeniden
    // kurulsa bile doğru "açık/kapalı" durumun anında geri yüklenmesini
    // sağlar.
    property var expandedState: ({})   // address -> bool

    function isExpandedForced(address) {
        return expandedState[address] === true
    }

    // ÖNEMLİ: Aynı anda sadece TEK bir pill açık (expanded) olabilir.
    // Bir pill'e tıklayıp açtığımızda, önceden açık olan başka bir pill
    // varsa TEK tıklamada (aynı anda) otomatik kapanır — çünkü bu fonksiyon
    // yeni state'i SIFIRDAN kurup sadece tıklanan adresi (varsa) true
    // yapıyor; önceki açık pill için ayrı bir "kapat" adımına gerek yok.
    function setExpandedForced(address, value) {
        const st = {}
        if (value) {
            st[address] = true   // diğer tüm adresler bu yeni objede hiç yok -> false
        }
        expandedState = st
    }

    // ---- Minimize/restore için saklama ----
    // Hyprland'de resmi bir "minimize" yok. Pencereyi sessizce sabit,
    // görünmeyen bir workspace'e taşıyarak "minimize" simüle ediyoruz (bkz.
    // WindowPill.qml: minimize()/restoreMinimized()). Orijinal workspace
    // ID'sini burada, adres bazlı bir map'te saklıyoruz ki restore tam
    // eski workspace'e geri dönebilsin.
    property var minimizedStash: ({})   // address -> {workspaceId}

    function isMinimized(address) {
        return Object.prototype.hasOwnProperty.call(minimizedStash, address)
    }

    // Minimize edilmiş pencereler ekranın alt kenarında yan yana
    // dizilirken hangi sırada duracağını belirler. minimizedStash bir JS
    // objesi olduğu için key ekleniş sırasını (insertion order) korur;
    // Object.keys() bu sırayla döner. Böylece pencereler minimize edildiği
    // sırayla soldan sağa dizilir.
    function minimizedIndexOf(address) {
        return Object.keys(minimizedStash).indexOf(address)
    }

    // Şu an minimize durumunda olan toplam pencere sayısı — noktaları
    // grup halinde ortalayabilmek için gerekiyor.
    function minimizedCount() {
        return Object.keys(minimizedStash).length
    }

    function minimizeWindow(address, geometry) {
        const stash = Object.assign({}, minimizedStash)
        // ÖNEMLİ (çoklu monitör minimize bug'ı — kök neden): pencere
        // "special:minimized" adlı TEK, PAYLAŞILAN özel workspace'e
        // taşındığında, Hyprland bu workspace'i her zaman AYNI monitöre
        // (genellikle en son o özel workspace'i açan/gösteren monitöre)
        // bağlıyor. Bunun sonucunda minimize edilen pencerenin
        // windowData.x/y'si ARTIK ORİJİNAL ekranını değil, özel
        // workspace'in bağlı olduğu (rastgele/son) monitörü yansıtıyor.
        // shell.qml'deki targetScreenName hesaplaması bu (artık YANLIŞ)
        // x/y'ye göre monitorFor() çağırdığı için, pill sessizce BAŞKA
        // monitöre "kayıyordu" (kullanıcının bildirdiği: "eDP-1'dekini
        // minimize edince HDMI'nin kenarına gidiyor").
        //
        // Çözüm: minimize ANINDA (pencere hâlâ orijinal ekranındayken)
        // doğru monitör adını STASH'e kaydediyoruz. WindowPill.qml artık
        // minimized durumdayken ekranı windowData.x/y'den DEĞİL, bu
        // sabitlenmiş isimden alacak.
        const mon = root.monitorFor(geometry.origX, geometry.origY)
        stash[address] = Object.assign({}, geometry, {
            monitorName: (mon && mon.name) ? mon.name : ""
        })
        minimizedStash = stash
        root.windows = root.windows.map(w => {
            if (w.address !== address) return w
            return Object.assign({}, w, { minimized: true })
        })
    }

    function restoreWindow(address) {
        const stash = Object.assign({}, minimizedStash)
        delete stash[address]
        minimizedStash = stash
        root.windows = root.windows.map(w => {
            if (w.address !== address) return w
            return Object.assign({}, w, { minimized: false })
        })
    }

    // ---- Pencere kapandığında temizlik ----
    // closewindow event'i geldiğinde adres artık geçersiz; bu adrese ait
    // kalıcı UI durumunu (expandedState) ve minimize stash'ini temizlemezsek
    // hafızada sonsuza kadar birikir. Ayrıca closewindow event'i bazen
    // Hyprland'in kendi `clients` listesini güncellemesinden BİRAZ önce
    // gelebiliyor; bu yüzden ilk refresh'ten kısa bir süre sonra ikinci bir
    // "temizleme" refresh'i daha atıyoruz ki pill kesin olarak kaybolsun.
    function cleanupAddress(address) {
        if (expandedState[address] !== undefined) {
            const st = Object.assign({}, expandedState)
            delete st[address]
            expandedState = st
        }
        if (Object.prototype.hasOwnProperty.call(minimizedStash, address)) {
            const stash = Object.assign({}, minimizedStash)
            delete stash[address]
            minimizedStash = stash
        }
    }

    Timer {
        id: closeSettleTimer
        interval: 150
        repeat: false
        onTriggered: root.refresh()
    }

    // ---- Aktif monitör geometrisi ----
    // Minimize (ekran dışına taşıma) ve "yarım ekran" boyutlandırma için
    // gerçek monitör sınırlarını biliyor olmamız gerekiyor; sabit bir
    // "-10000" gibi değerler bazı Hyprland sürümlerinde ekran sınırlarına
    // clamp edilebiliyor ya da monitör düzenine göre anlamsız kalabiliyor.
    property var monitors: []

    Process {
        id: monitorsProc
        command: ["hyprctl", "monitors", "-j"]
        stdout: StdioCollector {
            id: monitorsCollector
            onStreamFinished: {
                try {
                    root.monitors = JSON.parse(monitorsCollector.text)
                } catch (e) {
                    console.warn("HyprlandWindows: monitors parse error", e)
                }
            }
        }
    }

    function refreshMonitors() {
        monitorsProc.running = false
        monitorsProc.running = true
    }

    // windowX/windowY'nin üzerinde olduğu monitörü bulur; bulunamazsa ilk
    // monitörü (ya da null) döner.
    function monitorFor(x, y) {
        for (const m of root.monitors) {
            // ÖNEMLİ (çoklu monitör düzeltmesi): hyprctl'nin verdiği
            // width/height FİZİKSEL piksel cinsinden, ama x/y (ve
            // pencere koordinatları) Hyprland'in LOGICAL/layout
            // koordinat sisteminde (fiziksel / scale). scale != 1 olan
            // bir monitörde (ör. 3840x2160 @ scale 1.25) bunları
            // doğrudan karşılaştırmak monitörün logical sınırını
            // olduğundan büyük göstererek komşu monitörün alanını da
            // içine alıyordu — bu da eDP-1'in pillerinin hiç
            // oluşturulmamasına (hep HDMI'ye ait sayılmasına) yol
            // açıyordu. Karşılaştırmadan önce scale'e bölerek logical
            // genişlik/yüksekliğe çeviriyoruz.
            const scale = (m.scale && m.scale > 0) ? m.scale : 1
            const logicalW = m.width / scale
            const logicalH = m.height / scale
            if (x >= m.x && x < m.x + logicalW && y >= m.y && y < m.y + logicalH) {
                return m
            }
        }
        // ÖNEMLİ (monitörler arası "ölü bölge" düzeltmesi): Yukarıdaki
        // döngü hiçbir monitörün sınırlarının noktayı içermediğini
        // bulduysa (ör. üst kenarları hizalı olmayan iki farklı boyuttaki
        // monitör arasında oluşan boşluk — bu kurulumda tam olarak
        // HDMI-A-1 (3840x2160, (0,0)) ile eDP-1 (1920x1200, (3840,960))
        // arasında x>=3840 && y<960 bölgesi böyle bir "ölü bölge"),
        // ESKİDEN sabit "root.monitors[0]" (ilk monitör) döndürülüyordu.
        // Bu, pencere/pill bu boşluktan geçerken (ör. sürükleme sırasında)
        // GERÇEKTE hangi monitöre yakın olduğuna bakılmaksızın hep AYNI
        // monitöre kilitleniyordu — bu da margin hesaplarının yanlış
        // monitörün offset'ine göre yapılmasına (pill'in "yanlış
        // ölçekte"/yanlış konumda görünmesine) ve isOnCorrectScreen'in
        // yanlış PanelWindow instance'ını seçmesine (pill'in kaybolmasına)
        // yol açıyordu. Çözüm: tam eşleşme yoksa, noktayı her monitörün
        // sınırlarına "clamp" edip Öklid mesafesi EN KÜÇÜK olan monitörü
        // (yani GERÇEKTE en yakın olanı) seçiyoruz. Böylece boşluktan
        // geçiş sırasında pill, iki monitör arasındaki geometrik orta
        // noktada sorunsuzca bir monitörden diğerine geçer.
        let closest = null
        let closestDist = Infinity
        for (const m of root.monitors) {
            const scale = (m.scale && m.scale > 0) ? m.scale : 1
            const logicalW = m.width / scale
            const logicalH = m.height / scale
            const cx = Math.max(m.x, Math.min(x, m.x + logicalW))
            const cy = Math.max(m.y, Math.min(y, m.y + logicalH))
            const dist = (x - cx) * (x - cx) + (y - cy) * (y - cy)
            if (dist < closestDist) {
                closestDist = dist
                closest = m
            }
        }
        return closest
    }

    // ---- Aktif pencereyi bul, focused bayrağını işaretle ----
    Process {
        id: activeWinProc
        command: ["hyprctl", "activewindow", "-j"]
        stdout: StdioCollector {
            id: activeCollector
            onStreamFinished: {
                try {
                    const active = JSON.parse(activeCollector.text)
                    if (!active || !active.address) return
                    // Sadece focused durumu GERÇEKTEN değişen pencerelere
                    // yeni referans ver (bkz. refreshGeometryOnly'deki not).
                    const mapped = root.windows.map(w => {
                        const shouldBeFocused = w.address === active.address
                        if (w.focused === shouldBeFocused) return w
                        return Object.assign({}, w, { focused: shouldBeFocused })
                    })
                    const anyChanged = mapped.some((w, i) => w !== root.windows[i])
                    if (anyChanged) {
                        root.windows = mapped
                    }
                } catch (e) {
                    // Odakta pencere yoksa (boş workspace) JSON boş/hatalı olabilir, sessizce geç
                }
            }
        }
    }

    // ---- socket2 event stream: canlı dinleme ----
    // nc/socat yerine Hyprland'in kendi unix socket'ine doğrudan bağlanıyoruz.
    //
    // ÖNEMLİ (asıl kök neden bulundu): Quickshell'in Socket component'i
    // BİLİNEN bir sorun olarak event stream'i SESSİZCE disconnect edip
    // hiç yeniden bağlanmıyor (bkz. noctalia-shell #2200 - "NiriService
    // event stream socket silently disconnects, freezing workspace
    // widget"). Bizim durumumuzda da connected:true bir kerelik ayar
    // olduğu için, bağlantı bir noktada koptuğunda closewindow/openwindow
    // gibi hiçbir event bir daha ASLA gelmiyordu — root.windows sonsuza
    // dek eski haliyle kalıyor, bu yüzden kapanan pencerenin pili kalıcı
    // olarak duruyor, yeni açılana hiç pil eklenmiyordu. Üç turdur
    // denenen HyprlandWindows.qml'deki refresh()/kuyruklama fix'lerinin
    // hiçbirinin işe yaramamasının asıl sebebi buydu: event'ler zaten
    // hiç ulaşmıyordu, kuyruklama mantığı hiç devreye girmiyordu.
    //
    // Çözüm: onConnectedChanged ile disconnect algılanır algılanmaz kısa
    // bir gecikmeyle yeniden bağlanıyoruz.
    Socket {
        id: eventSocket
        // ÖNEMLİ: path boşken ("") Socket bağlanmayı denemesin diye
        // "connected" başlangıçta false; resolvedHyprSig dolup path
        // geçerli bir değere kavuştuğunda aşağıdaki onResolvedHyprSigChanged
        // handler'ı connected'i true yapıyor.
        path: root.socketPath("socket2")
        connected: false

        onConnectedChanged: {
            if (!connected) {
                // Bağlantı koptuysa: hem kısa bir süre sonra tekrar dene,
                // hem de signature'ın hâlâ doğru olduğundan emin olmak için
                // yeniden çözümle (Hyprland yeniden başlatıldıysa/reload
                // edildiyse signature değişmiş olabilir).
                reconnectTimer.restart()
            } else {
                // Yeniden bağlanır bağlanmaz, kopukluk sırasında kaçırılmış
                // olabilecek her şeyi telafi etmek için tam bir refresh yap.
                root.refresh()
            }
        }

        parser: SplitParser {
            splitMarker: "\n"
            onRead: line => {
                // Yapısal olaylar (pencere SAYISI değişebilir): tam
                // yeniden inşa. Diğer her şey (floating/fullscreen/title
                // değişimi dahil) YERİNDE güncellenir; aksi halde her
                // floating değişiminde (ör. sürükleme başlangıcında
                // setfloating çağrısı) tüm pill'ler yeniden kurulup açık
                // durumları/animasyonları sıfırlanıyordu.
                if (line.startsWith("closewindow>>")) {
                    const closedAddr = line.substring("closewindow>>".length).trim()
                    if (closedAddr) root.cleanupAddress(closedAddr)
                    root.refresh()
                    closeSettleTimer.restart()
                    return
                }

                if (line.startsWith("openwindow>>")
                    || line.startsWith("workspace>>")
                    || line.startsWith("moveworkspace>>")) {
                    root.refresh()
                    return
                }

                // Sadece konum/boyut/floating/title değişen olaylar: mevcut
                // pill instance'larını YENİDEN OLUŞTURMADAN, sadece ilgili
                // alanları yerinde güncelle. Bu, fare hareketiyle (sürükleme
                // sırasında sürekli ateşlenen movewindow/movewindowv2, ve
                // sürükleme başında bir kerelik changefloatingmode) pill'lerin
                // kapanıp yeniden açılmasını (expandedForced sıfırlanmasını)
                // engeller.
                if (line.startsWith("movewindow>>")
                    || line.startsWith("movewindowv2>>")
                    || line.startsWith("resizewindow>>")
                    || line.startsWith("changefloatingmode>>")
                    || line.startsWith("fullscreen>>")
                    || line.startsWith("windowtitle>>")) {
                    root.refreshGeometryOnly()
                    return
                }

                // Odak değişimi: focused bayrağını (activeWinProc ile) VE
                // fullscreen/geometri durumunu (refreshGeometryOnly ile)
                // birlikte tazele.
                //
                // ÖNEMLİ (düzeltildi): Daha önce burada SADECE activeWinProc
                // çalıştırılıyordu (yalnızca "focused" bayrağını günceller).
                // Ancak "fullscreen bir pencereden çıkıp BAŞKA bir pencereye
                // focus geçme" senaryosunda Hyprland bazen ayrı bir
                // "fullscreen>>" event'i YOLLAMADAN sadece "activewindow>>"
                // gönderiyor (fullscreen'den çıkış, focus değişimiyle aynı
                // anda/örtüşük gerçekleşiyor). Bu durumda root.windows'taki
                // eski pencerenin "fullscreen" alanı stale (hâlâ true)
                // kalıyordu; anyWindowFullscreen() de bu yüzden bir sonraki
                // 200ms'lik poll'a (ya da 600ms'lik tam refresh'e) kadar
                // hâlâ true dönüyor, pill'ler "anında değil, gecikmeli"
                // geri geliyordu. refreshGeometryOnly() da burada
                // çağrılarak fullscreen durumu artık activewindow ile AYNI
                // anda (event bazında, poll beklemeden) tazeleniyor.
                if (line.startsWith("activewindow>>")
                    || line.startsWith("activewindowv2>>")) {
                    activeWinProc.running = true
                    root.refreshGeometryOnly()
                }
            }
        }
    }

    Timer {
        id: reconnectTimer
        interval: 500
        repeat: false
        onTriggered: {
            // Yeniden denemeden önce signature'ı tazele: path o anda
            // güncellenmiş resolvedHyprSig'e göre yeniden hesaplanır
            // (path bir binding olduğu için resolvedHyprSig değiştiğinde
            // otomatik güncellenir), sonra bağlantıyı aç.
            root.resolveHyprSig()
            if (root.resolvedHyprSig) {
                eventSocket.connected = true
            } else {
                reconnectTimer.restart()
            }
        }
    }

    // resolvedHyprSig ilk kez (ya da yeniden) doldurulduğunda socket
    // bağlantısını (yeniden) kur. Path binding'i zaten otomatik güncellenir;
    // burada sadece "connected"i tetikliyoruz.
    onResolvedHyprSigChanged: {
        if (resolvedHyprSig) {
            eventSocket.connected = false
            Qt.callLater(() => { eventSocket.connected = true })
        }
    }

    // Güvenlik ağı: socket bağlantısı koparsa / kaçırılan bir event olursa
    // 200ms'de bir yedek yenileme yap (tiling animasyonları sırasında da
    // pozisyonların senkron kalması için).
    //
    // ÖNEMLİ (değişti): Daha önce sürükleme sırasında bu poll hızı 50ms'ye
    // çıkarılıyordu — saniyede 20 kez "hyprctl clients -j" fork+exec edilip
    // TÜM pencereler için JSON parse ediliyordu, sadece TEK bir sürüklenen
    // pencerenin konumunu güncel tutmak için. Bu hem gereksiz CPU/proses
    // yükü hem de fork+IPC gecikmesi yüzünden pill'in fareden hafif geride
    // kalmasına yol açıyordu.
    //
    // Artık sürüklenen pencerenin konumu WindowPill.qml içinde YEREL olarak
    // (fare deltasından, hiç IPC beklemeden) anlık güncelleniyor (bkz.
    // updateDraggedWindowLocal). hyprctl poll'u sürükleme sırasında ARTIK
    // HIZLANMIYOR — sabit 200ms'de kalıyor ve sadece gerçek (compositor
    // tarafındaki) konumla senkronizasyonu garanti eden bir güvenlik ağı
    // olarak çalışıyor; sürüklemenin akıcılığı ona bağlı değil.
    property bool dragActive: false

    Timer {
        // 200ms'den 400ms'e çıkarıldı: sürükleme zaten yerel takip ediliyor
        // (updateDraggedWindowLocal), bu sadece geometri drift'ini telafi
        // eden bir güvenlik ağı — saniyede 5 yerine 2.5 hyprctl fork'u.
        interval: 400
        running: true
        repeat: true
        onTriggered: {
            // ÖNEMLİ (monitör sınırında "geri sıçrama" düzeltmesi):
            // Sürükleme aktifken bu poll'u ATLIYORUZ. Sebep: sürüklenen
            // pencerenin GERÇEK (compositor'daki) konumu, movewindowpixel
            // dispatch edilip Hyprland tarafından işlenene kadar birkaç
            // karelik gecikmeyle güncelleniyor. Bu poll, updateDraggedWindowLocal
            // ile YEREL olarak (IPC beklemeden, fareyle bire bir) güncellenen
            // DAHA GÜNCEL konumu, hyprctl'nin HAFİF GERİDE KALAN gerçek
            // konum bilgisiyle eziyordu — bu da pilin, pencere aslında
            // hedef monitöre ulaşmış olsa bile, bir anlığına "eski"
            // (kaynak) monitörün konumuna göre hesaplanıp o ekrana
            // sıçramasına, sonra tekrar doğru monitöre dönmesine yol
            // açıyordu (sürüklemenin "kesilmesi" hissi de buradan
            // geliyordu — pil o an gerçek fareyle senkronizasyonunu
            // kaybediyordu). Sürükleme bittiğinde (dragActive false
            // olduğunda) WindowPill.qml zaten explicit bir
            // refreshGeometryOnly() çağrısı yapıyor, o yüzden burada
            // atlanan poll turları sürüklemenin sonunda otomatik telafi
            // ediliyor.
            if (!root.dragActive) {
                root.refreshGeometryOnly()
            }
        }
    }

    // Sürüklenen pencerenin konumunu YEREL olarak (hiçbir hyprctl
    // round-trip'i beklemeden) günceller. WindowPill.qml'in MouseArea'sı
    // her fare hareketinde bunu çağırır; böylece windowData.x/y her zaman
    // gerçeğe en yakın değeri taşır. Referans stabil tutulur (sadece hedef
    // pencere için yeni obje oluşturulur) ki diğer delegate'ler yeniden
    // kurulmasın.
    function updateDraggedWindowLocal(address, x, y) {
        const mapped = root.windows.map(w => {
            if (w.address !== address) return w
            if (w.x === x && w.y === y) return w
            return Object.assign({}, w, { x: x, y: y })
        })
        const anyChanged = mapped.some((w, i) => w !== root.windows[i])
        if (anyChanged) {
            root.windows = mapped
        }
    }

    // Ekstra güvenlik ağı: socket event'leri (nadiren de olsa) kaçırılırsa
    // ya da bağlantı yeniden kurulma sırasında bir şey atlanırsa, kısa
    // aralıklarla TAM yapısal refresh yaparak pencere listesinin uzun süre
    // bayat kalmamasını garantiliyoruz.
    // ÖNEMLİ (socket bağlanamama durumuna karşı dayanıklılık): socket2
    // event stream'i bağlı DEĞİLKEN (ör. resolvedHyprSig hâlâ boşsa ya da
    // Hyprland tarafında socket2 geçici olarak erişilemezse), pencere
    // açma/kapama/monitör-arası-sürükleme gibi YAPISAL değişiklikler SADECE
    // bu güvenlik timer'ına bağlı kalıyor. Socket bağlı değilken interval'i
    // 150ms'ye düşürüyoruz (bu modda TEK gerçek bilgi kaynağı odur);
    // bağlıyken (normal durum, socket2 asıl kaynak) 600ms yerine 1500ms'de
    // kalıyoruz ki gereksiz CPU/hyprctl fork yükü olmasın.
    Timer {
        id: structuralSafetyTimer
        interval: eventSocket.connected ? 1500 : 150
        running: true
        repeat: true
        onTriggered: {
            // ÖNEMLİ: sürükleme sırasında bu tam yapısal refresh de
            // ertelenir — aynı "eski konum eziyor" sorunu burada da
            // geçerli. Sürükleme bitince WindowPill.qml zaten kendi
            // refreshGeometryOnly() çağrısını yapıyor, o yüzden burada
            // atlanan turlar kayıp değil, sadece ertelenmiş oluyor.
            if (!root.dragActive) {
                root.refresh()
            }
        }
    }

    Component.onCompleted: {
        resolveHyprSig()
        refresh()
        refreshMonitors()
    }
}
