pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick

/*
  Colors
  ------
  matugen'in ürettiği ~/.config/quickshell/quickshell-pill/colors.json
  dosyasını okur ve Material You renk paletini dışarı açar.

  Dosya matugen her çalıştığında (wallpaper değiştiğinde vs.) yeniden
  yazıldığı için FileView + değişiklik izleme ile canlı güncelleniyor;
  ayrı bir yeniden başlatmaya gerek kalmadan pill renkleri anında değişir.

  matugen henüz çalıştırılmamışsa ya da dosya yoksa, makul varsayılan
  (mavi tonlu) bir palet kullanılır; böylece kurulum sırasında hata vermez.
*/
Item {
    id: root

    readonly property string colorsPath: Quickshell.env("HOME") + "/.config/quickshell/quickshell-pill/colors.json"

    // ---- Varsayılanlar (matugen henüz çalışmadıysa) ----
    property string primary: "#8ab4f8"
    property string textOnPrimary: "#00315c"
    property string primaryContainer: "#48586d"
    property string surface: "#1c1f26"
    property string textOnSurface: "#eceff4"
    property string surfaceContainer: "#2b2f3a"
    property string surfaceContainerHigh: "#343947"
    property string outline: "#8f9099"
    property string errorColor: "#e05a5a"
    property string textOnError: "#ffffff"
    property string tertiary: "#59c977"
    property string textOnTertiary: "#00391a"

    FileView {
        id: colorsFile
        path: root.colorsPath
        watchChanges: true

        onLoaded: {
            parseColors(text())
        }

        onLoadFailed: (error) => {
            console.warn("Colors: colors.json okunamadı (matugen henüz çalıştırılmamış olabilir), varsayılan renkler kullanılıyor.", error)
        }

        // ÖNEMLİ: watchChanges: true SADECE dosyadaki değişikliği ALGILAR;
        // otomatik olarak yeniden YÜKLEMEZ. Önceki koddaki yorum
        // ("ayrı bir onFileChanged sinyaline gerek yok") YANLIŞTI — bu
        // yüzden matugen dosyayı ilk kez oluşturduğunda ya da güncellediğinde
        // (Quickshell zaten çalışırken) pill renkleri hiç güncellenmiyordu;
        // sadece Quickshell'i YENİDEN BAŞLATINCA doğru renkler yükleniyordu.
        // onFileChanged içinde açıkça reload() çağırmak gerekiyor.
        onFileChanged: {
            reload()
        }
    }

    function parseColors(text) {
        try {
            const c = JSON.parse(text)
            if (c.primary) root.primary = c.primary
            if (c.on_primary) root.textOnPrimary = c.on_primary
            if (c.primary_container) root.primaryContainer = c.primary_container
            if (c.surface) root.surface = c.surface
            if (c.on_surface) root.textOnSurface = c.on_surface
            if (c.surface_container) root.surfaceContainer = c.surface_container
            if (c.surface_container_high) root.surfaceContainerHigh = c.surface_container_high
            if (c.outline) root.outline = c.outline
            if (c.error) root.errorColor = c.error
            if (c.on_error) root.textOnError = c.on_error
            if (c.tertiary) root.tertiary = c.tertiary
            if (c.on_tertiary) root.textOnTertiary = c.on_tertiary
        } catch (e) {
            console.warn("Colors: colors.json parse hatası", e)
        }
    }
}
