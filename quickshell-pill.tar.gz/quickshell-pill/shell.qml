import Quickshell
import QtQuick
import "./services" as Services
import "./components" as Components

ShellRoot {
    id: root

    // Hyprland monitör adını (ör. "DP-1") Quickshell.screens listesindeki
    // ShellScreen ile eşleştirir.
    function screenByName(name) {
        for (const s of Quickshell.screens) {
            if (s.name === name) return s
        }
        return null
    }

    // ÖNEMLİ (düzeltme — PanelWindow bir Item içine yerleştirilemez):
    // Önceki deneme "Repeater { model: Quickshell.screens; Item {
    // Repeater { ... WindowPill (PanelWindow) ... } } }" şeklinde iç içe
    // yapı kullanıyordu. PanelWindow bir top-level Window türüdür, normal
    // bir görsel Item DEĞİLDİR — bir Item'ın child'ı olarak konumlandırılmaya
    // çalışıldığında sessizce hiçbir surface oluşturulmuyor (hata da
    // vermiyor, sadece hiç görünmüyor). Bu, "iki ekranda da pill yok"
    // sonucunu doğrudan açıklıyor.
    //
    // Çözüm: TEK SEVİYELİ bir Repeater kullanıyoruz. Model, [pencere
    // sayısı × monitör sayısı] uzunluğunda düz bir index listesi
    // (0..N*M-1); her index'ten hem pencere index'ini hem monitör
    // index'ini çıkarıyoruz (div/mod). WindowPill'ler artık doğrudan
    // ShellRoot'un altında, hiçbir Item sarmalayıcı olmadan oluşturuluyor.
    readonly property int screenCount: Quickshell.screens.length

    property var pillSlots: []

    function _rebuildPillSlots() {
        const winCount = Services.HyprlandWindows.windows.length
        const scrCount = Quickshell.screens.length
        const total = winCount * scrCount
        if (pillSlots.length !== total) {
            const arr = []
            for (let i = 0; i < total; i++) arr.push(i)
            pillSlots = arr
        }
    }

    Connections {
        target: Services.HyprlandWindows
        function onWindowsChanged() { root._rebuildPillSlots() }
    }

    Connections {
        target: Quickshell
        function onScreensChanged() { root._rebuildPillSlots() }
    }

    Component.onCompleted: {
        _rebuildPillSlots()
    }

    // ÖNEMLİ (mimari değişiklik v4 — KESİN çözüm): Önceki TÜM yaklaşımlar
    // (screen'i hiç atamama, Loader ile yok edip yeniden kurma, screen'i
    // canlı binding yapma) ya pilleri göstermiyordu ya da monitör
    // sınırında titremeye/kaybolmaya yol açıyordu. Kanıtlanan gerçek:
    // PanelWindow.screen'in RUNTIME'da değişmesi (yeniden oluşturmadan ya
    // da canlı binding ile) Hyprland'in wlr-layer-shell implementasyonunda
    // GÜVENİLİR DEĞİL — bazı pencere boyutu/pozisyon kombinasyonlarında
    // sessizce hiç render edilmiyor, sınırda titriyor ya da kalıcı
    // kayboluyor.
    //
    // KESİN çözüm: screen'i ARTIK HİÇ DEĞİŞTİRMİYORUZ. Her pencere için,
    // HER MONİTÖRDE ayrı bir WindowPill instance'ı (PanelWindow) önceden
    // oluşturuluyor — screen ataması bu instance'ın ÖMRÜ boyunca SABİT
    // kalıyor (asla değişmiyor, asla yeniden kurulmuyor). Pencere hangi
    // monitördeyse, SADECE o monitöre ait instance "visible" oluyor;
    // diğer monitörlerdeki instance'lar sessizce visible=false kalıyor.
    // Pencere monitör değiştirdiğinde, artık HİÇBİR PanelWindow yok
    // edilmiyor/screen'i değiştirilmiyor — sadece HANGİ instance'ın
    // visible olduğu değişiyor (düz bir boolean toggle, layer-shell
    // seviyesinde hiçbir remap/surface değişikliği yok). Bu, hem titreme
    // hem kalıcı kaybolma sınıfı hataları YAPISAL olarak imkansız hale
    // getiriyor.
    Variants {
        model: root.pillSlots

        Components.WindowPill {
            id: pillInstance
            required property int modelData

            readonly property int _scrCount: Math.max(1, Quickshell.screens.length)
            readonly property int _winIdx: Math.floor(modelData / _scrCount)
            readonly property int _scrIdx: modelData % _scrCount

            readonly property var _win: Services.HyprlandWindows.windows[_winIdx]
            readonly property var _scr: Quickshell.screens[_scrIdx]

            // screen SABİT: bu instance'ın ömrü boyunca hiç değişmiyor
            // (aynı modelData her zaman aynı winIdx/scrIdx'e karşılık gelir).
            targetScreen: pillInstance._scr
            windowData: pillInstance._win

            isOnCorrectScreen: {
                // Bağımlılıkları üst seviyede oku (fonksiyon içine gömülü
                // property okumaları QML'de her zaman güvenilir şekilde
                // takip edilmiyor).
                const _depMonitors = Services.HyprlandWindows.monitors
                const _depStash = Services.HyprlandWindows.minimizedStash
                const w = pillInstance._win
                const s = pillInstance._scr
                if (!w || !s) return false

                let targetName = ""
                if (w.minimized === true) {
                    const stash = _depStash ? _depStash[w.address] : null
                    targetName = (stash && stash.monitorName) ? stash.monitorName : ""
                } else {
                    // ÖNEMLİ (monitör sınırında pill kaybolma düzeltmesi):
                    // Pencerenin SOL-ÜST köşesi (w.x, w.y) değil, pill'in
                    // GERÇEKTEN göründüğü nokta (pencerenin YATAY ORTASI —
                    // bkz. WindowPill.qml: _pillLeftX/margins, pill her
                    // zaman "windowData.x + windowData.w/2" etrafında
                    // ortalanır) kullanılmalı. Pencere iki monitör arasındaki
                    // sınırı geçerken (sürükleme sırasında) pencere GENİŞLİĞİ
                    // yüzünden sol-üst köşesi hâlâ eski monitördeyken pillin
                    // görsel merkezi ZATEN yeni monitöre geçmiş olabiliyordu
                    // (ya da tam tersi). Bu, isOnCorrectScreen'in (burada) ve
                    // WindowPill.qml'deki margin/_monOffset hesabının FARKLI
                    // monitörleri "doğru" sayıp pilin margin'ini artık kendi
                    // atandığı ekranın sınırları DIŞINA taşırmasına — yani
                    // pilin sınırda birden kaybolmasına — yol açıyordu.
                    // Çözüm: her ikisinde de AYNI referans noktasını (pencere
                    // yatay ortası) kullanmak.
                    const mon = Services.HyprlandWindows.monitorFor(w.x + w.w / 2, w.y)
                    targetName = (mon && mon.name) ? mon.name : ""
                }
                return targetName !== "" && targetName === s.name
            }
        }
    }
}
