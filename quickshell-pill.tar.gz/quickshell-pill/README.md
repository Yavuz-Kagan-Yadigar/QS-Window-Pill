# Hyprland Window Pill — Quickshell

Uygulama pencerelerinin normal başlık çubuğu yerine, pencere üst-orta
noktasında duran ince bir "pill" gösterir. Tıklayınca/hover'da yukarı
doğru kalınlaşır (konumu asla kaymaz), close / minimize / maximize
butonları çıkar. Tiling ve floating pencerelerde de çalışır; Hyprland
event stream'ini dinleyerek pozisyonu canlı günceller. Renkler matugen
üzerinden Material You paletini (duvar kağıdınıza göre) takip eder.

## Dosya yapısı

```
quickshell-pill/
├── shell.qml                     # giriş noktası
├── install.sh                    # kurulum betiği
├── services/
│   ├── qmldir                    # HyprlandWindows + Colors singleton tanımları
│   ├── HyprlandWindows.qml       # hyprctl + socket2 event stream ile pencere takibi
│   └── Colors.qml                # matugen colors.json'u okuyan renk paleti servisi
├── components/
│   ├── WindowPill.qml            # per-pencere layershell pill
│   └── PillButton.qml            # close/minimize/maximize daire buton
└── matugen/
    ├── pill-colors.json.template # matugen için JSON çıktı şablonu
    └── config-snippet.toml       # ~/.config/matugen/config.toml'a eklenecek blok
```

## Gereksinimler

- Quickshell (güncel bir sürüm; `PanelWindow`, `WlrLayershell`, `Socket`/`SplitParser`, `FileView` API'leri kullanılıyor)
- Hyprland (socket2 event stream ve `hyprctl` gerekiyor)
- Qt Quick Layouts modülü (genelde Quickshell ile birlikte gelir)
- (Opsiyonel ama önerilir) [matugen](https://github.com/InioX/matugen) — duvar kağıdına göre Material You renk paleti üretir. Kurulu değilse pill sabit varsayılan renklerle çalışır.

## Hyprland'e uygulamalarınızın kendi titlebar'ını kapatmayı unutmayın

Pencerelerin kendi native decoration'ı görünmesin diye `hyprland.conf`'a:

```
decoration {
    # ...
}

# Pencere kurallarıyla native titlebar'ı kapatmak isterseniz
windowrulev2 = noborder, class:.*
```

(Bu satır isteğe bağlı — sadece kendi WM/decoration temanıza göre native
titlebar'ı gizlemek istiyorsanız gerekir; pill zaten üstte bağımsız bir
layer-shell katmanı olarak durur.)

## Kurulum (otomatik)

```bash
cd /path/to/pill-files
chmod +x install.sh
./install.sh
```

Betik dosyaları `~/.config/quickshell/quickshell-pill/` altına doğru
alt-klasör yapısıyla yerleştirir, isterseniz `hyprland.conf`'a
`exec-once` satırını da otomatik ekler.

## Çalıştırma (manuel)

```bash
quickshell -p /path/to/quickshell-pill/shell.qml
```

Kalıcı kullanım için `~/.config/quickshell/` altına kopyalayıp

```bash
quickshell
```

komutuyla (config-adı ile) çalıştırabilir ya da Hyprland `exec-once` içine
ekleyebilirsiniz:

```
exec-once = quickshell -c quickshell-pill
```

(bu durumda klasörü `~/.config/quickshell/quickshell-pill/` yapıp
`-c quickshell-pill` ile çağırmanız gerekir.)

## Nasıl çalışıyor

1. **HyprlandWindows.qml** (singleton servis):
   - `hyprctl clients -j` ile tüm pencerelerin `x, y, w, h, floating,
     fullscreen, focused` bilgisini çeker.
   - Hyprland'in `$XDG_RUNTIME_DIR/hypr/$HYPRLAND_INSTANCE_SIGNATURE/socket2.sock`
     dosyasına bağlanıp `openwindow`, `closewindow`, `movewindow`,
     `movewindowv2`, `changefloatingmode`, `fullscreen`, `activewindow`,
     `workspace`, `resizewindow` event'lerini dinler. Bu event'lerden biri
     geldiğinde pencere listesini tazeler — **tiling layout değiştiğinde de
     (örn. yeni pencere açılıp mevcutlar küçüldüğünde) pill'ler otomatik
     kayar.**
   - Ek güvenlik: 2 saniyede bir yedek yenileme (animasyon sırasında kaçan
     event'lere karşı).

2. **WindowPill.qml** (her pencere için bir tane, `Variants` ile):
   - `PanelWindow` + `WlrLayershell.layer: Overlay` ile pencerenin ÜSTÜNDE
     bağımsız bir katman penceresi oluşturur.
   - **Layer-shell alanı sabittir**: pencere her zaman "açık" haldeki
     maksimum boyutu (220x34) kadar yer kaplar; bu alan hover'a göre
     büyüyüp küçülmez. Böylece fare imleci pill'in üstündeyken pill
     "büyüdüğü için" imlecin altındaki bölge değişmez, dolayısıyla
     imleç yanlışlıkla arkadaki pencereye düşüp hover'ın kesilmesi /
     titreme sorunu yaşanmaz.
   - Görsel pill (`Rectangle`) bu sabit alanın **alt kenarına yapışıktır**
     ve sadece **yukarı doğru kalınlaşarak** büyür — yatayda hiç kayma
     yok, sadece "olduğu yerde kalınlaşma".
   - `margins.left/top` hesaplaması: `pencere.x + pencere.w/2 - alan.w/2`
     → pencerenin üst kenarının tam ortasına oturur. Bu hesap `expanded`
     durumuna bağlı DEĞİLDİR, sadece pencere gerçekten taşındığında/
     tiling değiştiğinde güncellenir.
   - Kapalı halde: 64x6 px ince bir çubuk (aktif pencerede `Colors.primary`,
     diğerlerinde `Colors.outline`).
   - Hover ya da tıklamada: 220x34 px'e kalınlaşır, başlık metni + 3 buton
     (minimize / maximize-restore / close) belirir.
   - Butonlar `hyprctl dispatch` komutlarını (`closewindow`,
     `fullscreenstate`, `movetoworkspacesilent` ile minimize simülasyonu)
     tetikler.

3. **Colors.qml** (singleton):
   - `~/.config/quickshell/quickshell-pill/colors.json` dosyasını okur
     (matugen'in ürettiği Material You paleti) ve `FileView` ile canlı
     izler — dosya her güncellendiğinde (wallpaper değiştiğinde vs.)
     pill renkleri Quickshell'i yeniden başlatmadan otomatik değişir.
   - Dosya yoksa (matugen henüz çalıştırılmadıysa) sabit varsayılan
     renklerle çalışır, hata vermez.

## Notlar / iyileştirme fikirleri

- **Minimize**: Hyprland'de gerçek bir "minimize" kavramı yok; burada
  pencereyi `special:minimized` adlı özel bir workspace'e taşıyarak
  simüle ediyoruz. İsterseniz bunun yerine kendi minimize workspace
  isimlendirmenizi kullanabilir ya da bir taskbar/dock ile entegre
  edebilirsiniz.
- **Maximize**: Floating pencerelerde `resizeactive exact 100% 100%` +
  `moveactive exact 0 0` ile pencere kendi workspace'i içinde ekranı
  kaplayacak şekilde büyütülür (tiling düzeni etkilenmez). Tiling
  pencerelerde ise `resizeactive`/`moveactive` anlamsız kalacağından
  (boyutu tiling algoritması belirliyor), Hyprland'in "maximize-in-place"
  fullscreen modu (`fullscreenstate 0 1`) kullanılır — pencere diğer
  pencerelerin yerini bozmadan geçici olarak tam ekran görünümü alır.
- **Görsel tema (matugen / Material You)**: Renkler artık
  `services/Colors.qml` üzerinden `~/.config/quickshell/quickshell-pill/colors.json`
  dosyasından okunuyor. Bunu matugen ile otomatik üretmek için:
  1. `matugen/config-snippet.toml` içeriğini `~/.config/matugen/config.toml`
     dosyanıza ekleyin (yoksa bu dosyayı oluşturun).
  2. `matugen image /path/to/wallpaper.jpg` çalıştırın (ya da matugen'i
     wallpaper değiştirici scriptinize entegre edin, örn. `swww`/`hyprpaper`
     sonrası otomatik tetiklensin).
  3. `colors.json` güncellendiği an pill renkleri, Quickshell'i yeniden
     başlatmadan, canlı olarak değişir.
  matugen kurulu değilse pill `Colors.qml` içindeki sabit varsayılan
  renklerle (mavi tonlu) çalışmaya devam eder.
- **Performans**: Çok sayıda pencere açıkken 2 saniyelik polling +
  event-driven refresh birlikte çalışıyor; isterseniz polling aralığını
  artırıp tamamen event-driven'a geçebilirsiniz.
